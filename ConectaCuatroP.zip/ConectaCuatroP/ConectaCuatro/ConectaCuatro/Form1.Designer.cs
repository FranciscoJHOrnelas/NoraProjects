﻿namespace ConectaCuatro
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnColumna1 = new System.Windows.Forms.Button();
            this.btnColumna2 = new System.Windows.Forms.Button();
            this.btnColumna4 = new System.Windows.Forms.Button();
            this.btnColumna3 = new System.Windows.Forms.Button();
            this.btnColumna6 = new System.Windows.Forms.Button();
            this.btnColumna5 = new System.Windows.Forms.Button();
            this.btnColumna7 = new System.Windows.Forms.Button();
            this.lblPtjAm = new System.Windows.Forms.Label();
            this.lblPtjRj = new System.Windows.Forms.Label();
            this.lblEmpate = new System.Windows.Forms.Label();
            this.btnReiniciar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnColumna1
            // 
            this.btnColumna1.BackColor = System.Drawing.Color.Red;
            this.btnColumna1.Location = new System.Drawing.Point(39, 35);
            this.btnColumna1.Name = "btnColumna1";
            this.btnColumna1.Size = new System.Drawing.Size(50, 50);
            this.btnColumna1.TabIndex = 0;
            this.btnColumna1.UseVisualStyleBackColor = false;
            this.btnColumna1.Click += new System.EventHandler(this.PonerFicha);
            // 
            // btnColumna2
            // 
            this.btnColumna2.BackColor = System.Drawing.Color.Red;
            this.btnColumna2.Location = new System.Drawing.Point(137, 35);
            this.btnColumna2.Name = "btnColumna2";
            this.btnColumna2.Size = new System.Drawing.Size(50, 50);
            this.btnColumna2.TabIndex = 1;
            this.btnColumna2.UseVisualStyleBackColor = false;
            this.btnColumna2.Click += new System.EventHandler(this.PonerFicha);
            // 
            // btnColumna4
            // 
            this.btnColumna4.BackColor = System.Drawing.Color.Red;
            this.btnColumna4.Location = new System.Drawing.Point(337, 35);
            this.btnColumna4.Name = "btnColumna4";
            this.btnColumna4.Size = new System.Drawing.Size(50, 50);
            this.btnColumna4.TabIndex = 3;
            this.btnColumna4.UseVisualStyleBackColor = false;
            this.btnColumna4.Click += new System.EventHandler(this.PonerFicha);
            // 
            // btnColumna3
            // 
            this.btnColumna3.BackColor = System.Drawing.Color.Red;
            this.btnColumna3.Location = new System.Drawing.Point(239, 35);
            this.btnColumna3.Name = "btnColumna3";
            this.btnColumna3.Size = new System.Drawing.Size(50, 50);
            this.btnColumna3.TabIndex = 2;
            this.btnColumna3.UseVisualStyleBackColor = false;
            this.btnColumna3.Click += new System.EventHandler(this.PonerFicha);
            // 
            // btnColumna6
            // 
            this.btnColumna6.BackColor = System.Drawing.Color.Red;
            this.btnColumna6.Location = new System.Drawing.Point(533, 35);
            this.btnColumna6.Name = "btnColumna6";
            this.btnColumna6.Size = new System.Drawing.Size(50, 50);
            this.btnColumna6.TabIndex = 5;
            this.btnColumna6.UseVisualStyleBackColor = false;
            this.btnColumna6.Click += new System.EventHandler(this.PonerFicha);
            // 
            // btnColumna5
            // 
            this.btnColumna5.BackColor = System.Drawing.Color.Red;
            this.btnColumna5.Location = new System.Drawing.Point(435, 35);
            this.btnColumna5.Name = "btnColumna5";
            this.btnColumna5.Size = new System.Drawing.Size(50, 50);
            this.btnColumna5.TabIndex = 4;
            this.btnColumna5.UseVisualStyleBackColor = false;
            this.btnColumna5.Click += new System.EventHandler(this.PonerFicha);
            // 
            // btnColumna7
            // 
            this.btnColumna7.BackColor = System.Drawing.Color.Red;
            this.btnColumna7.Location = new System.Drawing.Point(628, 35);
            this.btnColumna7.Name = "btnColumna7";
            this.btnColumna7.Size = new System.Drawing.Size(50, 50);
            this.btnColumna7.TabIndex = 6;
            this.btnColumna7.UseVisualStyleBackColor = false;
            this.btnColumna7.Click += new System.EventHandler(this.PonerFicha);
            // 
            // lblPtjAm
            // 
            this.lblPtjAm.AutoSize = true;
            this.lblPtjAm.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPtjAm.Location = new System.Drawing.Point(799, 55);
            this.lblPtjAm.Name = "lblPtjAm";
            this.lblPtjAm.Size = new System.Drawing.Size(259, 28);
            this.lblPtjAm.TabIndex = 7;
            this.lblPtjAm.Text = "Puntaje Amarillo: 0";
            // 
            // lblPtjRj
            // 
            this.lblPtjRj.AutoSize = true;
            this.lblPtjRj.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPtjRj.Location = new System.Drawing.Point(799, 138);
            this.lblPtjRj.Name = "lblPtjRj";
            this.lblPtjRj.Size = new System.Drawing.Size(207, 28);
            this.lblPtjRj.TabIndex = 8;
            this.lblPtjRj.Text = "Puntaje Rojo: 0";
            // 
            // lblEmpate
            // 
            this.lblEmpate.AutoSize = true;
            this.lblEmpate.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpate.Location = new System.Drawing.Point(799, 210);
            this.lblEmpate.Name = "lblEmpate";
            this.lblEmpate.Size = new System.Drawing.Size(142, 28);
            this.lblEmpate.TabIndex = 9;
            this.lblEmpate.Text = "Empates: 0";
            // 
            // btnReiniciar
            // 
            this.btnReiniciar.Font = new System.Drawing.Font("Consolas", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReiniciar.Location = new System.Drawing.Point(804, 284);
            this.btnReiniciar.Name = "btnReiniciar";
            this.btnReiniciar.Size = new System.Drawing.Size(211, 47);
            this.btnReiniciar.TabIndex = 10;
            this.btnReiniciar.Text = "Reiniciar";
            this.btnReiniciar.UseVisualStyleBackColor = true;
            this.btnReiniciar.Click += new System.EventHandler(this.btnReiniciar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1182, 753);
            this.Controls.Add(this.btnReiniciar);
            this.Controls.Add(this.lblEmpate);
            this.Controls.Add(this.lblPtjRj);
            this.Controls.Add(this.lblPtjAm);
            this.Controls.Add(this.btnColumna7);
            this.Controls.Add(this.btnColumna6);
            this.Controls.Add(this.btnColumna5);
            this.Controls.Add(this.btnColumna4);
            this.Controls.Add(this.btnColumna3);
            this.Controls.Add(this.btnColumna2);
            this.Controls.Add(this.btnColumna1);
            this.Name = "Form1";
            this.Text = "Conecta Cuatro";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnColumna1;
        private System.Windows.Forms.Button btnColumna2;
        private System.Windows.Forms.Button btnColumna4;
        private System.Windows.Forms.Button btnColumna3;
        private System.Windows.Forms.Button btnColumna6;
        private System.Windows.Forms.Button btnColumna5;
        private System.Windows.Forms.Button btnColumna7;
        private System.Windows.Forms.Label lblPtjAm;
        private System.Windows.Forms.Label lblPtjRj;
        private System.Windows.Forms.Label lblEmpate;
        private System.Windows.Forms.Button btnReiniciar;
    }
}

