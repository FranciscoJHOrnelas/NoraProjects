﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConectaCuatro
{
    public partial class Form1 : Form
    {
        public PictureBox[,] Mapa = new PictureBox[7,7];
        public Button[] Botones = new Button[7];
        public string M="";
        public int ScoreAmarillo, ScoreRojo, Empate;
        public Form1()
        {
            InitializeComponent();
            Botones[0] = btnColumna1;
            Botones[1] = btnColumna2;
            Botones[2] = btnColumna3;
            Botones[3] = btnColumna4;
            Botones[4] = btnColumna5;
            Botones[5] = btnColumna6;
            Botones[6] = btnColumna7;
            for(int x =0; x<7;x++)
            {
                //M += "/";
                for(int i = 0; i<7; i++)
                {
                    M += "-";
                }
            }
            //M += "/";
        }
        public void CambioColor()
        {
            for(int b = 0; b<Botones.Length;b++)
            {
                if (Botones[b].BackColor == Color.FromArgb(255, 255, 0))
                {
                    Botones[b].BackColor = Color.FromArgb(255, 0, 0);
                }
                else
                {
                    Botones[b].BackColor = Color.FromArgb(255, 255, 0);
                }
            }
        }
        private void PonerFicha(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int Col = (btn.TabIndex);
            Point loc = Botones[Col].Location;
            for (int L = 0; L < 7; L++)
            {
                if (Mapa[Col, L] == null )
                {
                    PictureBox PBX = new PictureBox();
                    this.Controls.Add(PBX);
                    PBX.Size = btn.Size;
                    PBX.BackColor = btn.BackColor;
                    PBX.Location = new Point(loc.X, loc.Y+(450-(L*50)));
                    Mapa[Col, L] = PBX;
                    RegMovimiento(PBX, L, Col);
                    if(L==6)
                    {
                        btn.Visible = false;
                    }
                    break;
                } 
            }
        }

        public void RegMovimiento(PictureBox PBX, int L, int Col)
        {
            //Console.WriteLine(M.Length);
            //Console.WriteLine(M);
            int NPosition = (Col * 7) + L;
            string N = M;
            M = "";
            for(int A =0;A<N.Length;A++)
            {
                if (A == NPosition)
                {
                    if (PBX.BackColor == Color.FromArgb(255, 255, 0))
                    {
                        M += "Y";
                    }
                    else //if (PBX.BackColor == Color.FromArgb(255, 0, 0))
                    {
                        M += "R";
                    }
                    
                }
                else
                {
                    //Console.WriteLine(N.Substring(A, 1));
                    M += N.Substring(A, 1);
                }
            }
            CambioColor();
            Revisar();
            //Console.WriteLine(M.Length);
            for(int i=0;i<7;i++)
            {
                Console.WriteLine(M.Substring(i * 7, 7));
            }
            Console.WriteLine(M);

        }

        public void Revisar()
        {
            for(int A=0;A<M.Length;A++)
            {
                if (M.Substring(A, 1) != "-")
                {
                    if ((A > 2 && A < 7) || (A > 9 && A < 14) || (A > 16 && A < 21) || (A > 23 && A<28) || 
                        (A>30 && A<35) || (A>37 && A<42) || (A>44 && A<49))
                    {
                        if(M.Substring(A-3,4)=="RRRR" || M.Substring(A-3,4)=="YYYY") // Vertical
                        {
                            Console.WriteLine("VICTORIA al " + M.Substring(A - 3, 4));
                            Inhabilitar(M.Substring(A, 1));
                            break;
                        }
                    }
                    if (A + 21 < M.Length) // Horizontal
                    {
                        if (M.Substring(A, 1) == M.Substring(A + 7, 1) && M.Substring(A, 1) == M.Substring(A + 14, 1)
                             && M.Substring(A, 1) == M.Substring(A + 21, 1))
                        {
                            Console.WriteLine("VICTORIA " + M.Substring(A, 1));
                            Inhabilitar(M.Substring(A, 1));
                            break;
                        }
                    }
                    if (A+24<M.Length && ((A<4 || A>6) && (A<11 || A>13)) && (A<18 || A>20)) //Diagonal creciente
                    {
                        if(M.Substring(A,1) == M.Substring(A+8,1) && M.Substring(A,1) == M.Substring(A+16,1)
                             && M.Substring(A, 1) == M.Substring(A + 24, 1))
                        {
                            Console.WriteLine("VICTORIA al " + M.Substring(A, 1));
                            Inhabilitar(M.Substring(A, 1));
                            break;
                        }
                    }
                    if (A + 17 < M.Length && ((A > 2 && A < 7) || (A > 9 && A < 14) || (A > 16 && A < 21) || (A>23 && A<28))) //Diagonal decreciente
                    {
                        if (M.Substring(A, 1) == M.Substring(A + 6, 1) && M.Substring(A, 1) == M.Substring(A + 12, 1)
                             && M.Substring(A, 1) == M.Substring(A + 18, 1))
                        {
                            Console.WriteLine("VICTORI " + M.Substring(A, 1));
                            Inhabilitar(M.Substring(A,1));
                            break;
                        }
                    }
                    
                }
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            if (!M.Contains("-"))
            {
                Empate++;
            }
            M = "";
            lblEmpate.Text = "Empates: " + Empate.ToString();
            for (int x = 0; x < 7; x++)
            {
                //M += "/";
                Botones[x].Enabled = true;
                Botones[x].Visible = true;
                for (int i = 0; i < 7; i++)
                {
                    M += "-";
                    if(Mapa[x,i]!=null)
                    {
                        Mapa[x, i].Dispose();
                        Mapa[x, i] = null;
                    }
                }
            }
            
        }

        public void Inhabilitar(string Ganador)
        {
            for (int i = 0; i < Botones.Length; i++)
            {
                Botones[i].Visible = false;
            }
            switch(Ganador)
            {
                case "Y":
                    {
                        Console.WriteLine("Gana el amarillo");
                        ScoreAmarillo += 1;
                        lblPtjAm.Text = "Puntaje Amarillo: " + ScoreAmarillo.ToString();
                        break;
                    }
                case "R":
                    {
                        Console.WriteLine("Gana el rojo");
                        ScoreRojo += 1;
                        lblPtjRj.Text = "Puntaje Rojo: " + ScoreRojo.ToString();
                        break;
                    }

            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }

}
