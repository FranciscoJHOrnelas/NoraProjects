﻿namespace Snake
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PbxTablero = new System.Windows.Forms.PictureBox();
            this.BtnIniciar = new System.Windows.Forms.Button();
            this.lblPoints = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PbxTablero)).BeginInit();
            this.SuspendLayout();
            // 
            // PbxTablero
            // 
            this.PbxTablero.BackColor = System.Drawing.Color.LightSlateGray;
            this.PbxTablero.Location = new System.Drawing.Point(12, 12);
            this.PbxTablero.Name = "PbxTablero";
            this.PbxTablero.Size = new System.Drawing.Size(10, 10);
            this.PbxTablero.TabIndex = 0;
            this.PbxTablero.TabStop = false;
            this.PbxTablero.Paint += new System.Windows.Forms.PaintEventHandler(this.PbxTablero_Paint);
            // 
            // BtnIniciar
            // 
            this.BtnIniciar.BackColor = System.Drawing.Color.LightSlateGray;
            this.BtnIniciar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnIniciar.Font = new System.Drawing.Font("Consolas", 22.2F);
            this.BtnIniciar.ForeColor = System.Drawing.SystemColors.GrayText;
            this.BtnIniciar.Location = new System.Drawing.Point(12, 124);
            this.BtnIniciar.Name = "BtnIniciar";
            this.BtnIniciar.Size = new System.Drawing.Size(258, 75);
            this.BtnIniciar.TabIndex = 1;
            this.BtnIniciar.Text = "Iniciar";
            this.BtnIniciar.UseVisualStyleBackColor = false;
            this.BtnIniciar.Click += new System.EventHandler(this.BtnIniciar_Click);
            this.BtnIniciar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnIniciar_KeyDown);
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblPoints.Font = new System.Drawing.Font("Consolas", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoints.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblPoints.Location = new System.Drawing.Point(32, 43);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(238, 51);
            this.lblPoints.TabIndex = 2;
            this.lblPoints.Text = "Puntos: 0";
            this.lblPoints.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Controls.Add(this.lblPoints);
            this.Controls.Add(this.BtnIniciar);
            this.Controls.Add(this.PbxTablero);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Snake";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PbxTablero)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PbxTablero;
        private System.Windows.Forms.Button BtnIniciar;
        private System.Windows.Forms.Label lblPoints;
    }
}

