﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snake
{
    public partial class Form1 : Form
    {
        public Point[] CordSnake = new Point[4];
        public Point Apple;
        public Point Limit = new Point(680,380);
        public int Points=0;
        public bool DirBlock = false;
        public int Rot = 45;
        public int Vel = 100;
        public int Vertical=0;
        public int Horizontal = 20;
        Timer t = null;
        private void StartTimer()
        {
            t = new Timer();
            t.Interval = Vel;
            t.Tick += new EventHandler(t_Tick);
            t.Enabled = true;
        }
        void t_Tick(object sender, EventArgs e)
        {
            DirBlock = false;
            Draw();
            Check();
        }
        public Form1()
        {
            InitializeComponent();
        }
        public void Check()
        {
            if (CordSnake[0].X > Limit.X || CordSnake[0].Y > Limit.Y || CordSnake[0].X < 0 || CordSnake[0].Y < 0 || CordSnake.Length != CordSnake.Distinct().Count())
            {
                Console.WriteLine(CordSnake.Length + "L - DC" + CordSnake.Distinct().Count());
                BtnIniciar.Visible = true;
                t.Enabled = false;
            }
            if (Apple ==CordSnake[0])
            {
                Console.WriteLine("AJUA");
                Random rand = new Random();
                GA:
                Console.WriteLine("AJUAA");
                Point A = new Point(rand.Next(0, 35)*20, rand.Next(0, 20)*20);
                if(CordSnake.Contains(A))
                {
                    goto GA;
                }
                Array.Resize(ref CordSnake, CordSnake.Length + 1);
                CordSnake[CordSnake.Length - 1] = new Point((CordSnake[CordSnake.Length - 2].X-Horizontal),CordSnake[CordSnake.Length-2].Y+Vertical); //Dirección
                Apple = A;
                Points++;
                lblPoints.Text = "Puntos: " + Points.ToString();
                if(Points%3==0 && Vel>40)
                {
                    Vel -= 10;
                    t.Interval = Vel;
                }
            }
            
        }
        public void Draw()
        {
            
            for(int i=1;i<CordSnake.Length;i++)
            {
                CordSnake[CordSnake.Length-i] = CordSnake[CordSnake.Length-(i+1)];
                //CordSnake[i] = new Point(CordSnake[i].X, CordSnake[i].Y); //Dirección
            }
            CordSnake[0].X += Horizontal;
            CordSnake[0].Y -= Vertical;
            PbxTablero.Refresh();
            Console.WriteLine(CordSnake[0].X + "-" + CordSnake[0].Y);
        }
        private void PbxTablero_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawPie(new Pen(Color.Aquamarine, 2f), CordSnake[0].X, CordSnake[0].Y, 20, 20, Rot, 270);
            
            //45, 270 derecha
            //135, 270 abajo
            //225, 270 izquierda
            //315, 270 arriba
            for (int i=1;i<CordSnake.Length;i++)
            {
                    e.Graphics.DrawEllipse(
                    new Pen(Color.Black, 2f),
                    CordSnake[i].X, CordSnake[i].Y, 20, 20);
            }
            e.Graphics.DrawEllipse(new Pen(Color.Red, 2f), Apple.X, Apple.Y, 20, 20);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void BtnIniciar_Click(object sender, EventArgs e)
        {
            if(BtnIniciar.Text=="Iniciar")
            {
                lblPoints.Location = new Point(720, 50);
                lblPoints.Visible = true;
                CordSnake[0] = new Point(80, 100);
                CordSnake[1] = new Point(CordSnake[0].X - Horizontal, CordSnake[0].Y - Vertical);
                CordSnake[2] = new Point(CordSnake[1].X - Horizontal, CordSnake[1].Y - Vertical);
                CordSnake[3] = new Point(CordSnake[2].X - Horizontal, CordSnake[2].Y - Vertical);
                Apple = new Point(400, 100);
                PbxTablero.Size = new Size(700, 400);
                PbxTablero.Location = new Point(0, 0);
                this.Size = new Size(1020, 480);
                StartTimer();
                BtnIniciar.Visible = false;
                BtnIniciar.Text = "Reiniciar";
                BtnIniciar.Location = new Point(720, 300);  
            }
            else if(BtnIniciar.Text=="Reiniciar")
            {
                Application.Restart();
            }
            
        }
        private void BtnIniciar_KeyDown(object sender, KeyEventArgs e)
        {
            if (DirBlock == false)
            {
                if (e.KeyCode == Keys.Right && Horizontal != -20)
                {
                    DirBlock = true;
                    Horizontal = 20;
                    Vertical = 0;
                    Rot = 45;
                }
                if (e.KeyCode == Keys.Left && Horizontal != 20)
                {
                    DirBlock = true;
                    Horizontal = -20;
                    Vertical = 0;
                    Rot = 225;
                }
                if (e.KeyCode == Keys.Up && Vertical != -20)
                {
                    DirBlock = true;
                    Vertical = 20;
                    Horizontal = 0;
                    Rot = 315;
                }
                if (e.KeyCode == Keys.Down && Vertical != 20)
                {
                    DirBlock = true;
                    Vertical = -20;
                    Horizontal = 0;
                    Rot = 135;
                }
            }
        }
    }
}
