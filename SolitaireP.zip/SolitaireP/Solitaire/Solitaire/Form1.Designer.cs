﻿namespace Solitaire
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnMazo = new System.Windows.Forms.Button();
            this.BtnMazoVisible = new System.Windows.Forms.Button();
            this.BtnReiniciar = new System.Windows.Forms.Button();
            this.BtnMetaA = new System.Windows.Forms.Button();
            this.BtnMetaB = new System.Windows.Forms.Button();
            this.BtnMetaC = new System.Windows.Forms.Button();
            this.BtnMetaD = new System.Windows.Forms.Button();
            this.LblMoves = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnMazo
            // 
            this.BtnMazo.AutoSize = true;
            this.BtnMazo.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMazo.Location = new System.Drawing.Point(38, 29);
            this.BtnMazo.Name = "BtnMazo";
            this.BtnMazo.Size = new System.Drawing.Size(75, 75);
            this.BtnMazo.TabIndex = 0;
            this.BtnMazo.Text = "MAZO";
            this.BtnMazo.UseVisualStyleBackColor = true;
            this.BtnMazo.Click += new System.EventHandler(this.BtnMazo_Click);
            // 
            // BtnMazoVisible
            // 
            this.BtnMazoVisible.Enabled = false;
            this.BtnMazoVisible.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMazoVisible.Location = new System.Drawing.Point(146, 29);
            this.BtnMazoVisible.Name = "BtnMazoVisible";
            this.BtnMazoVisible.Size = new System.Drawing.Size(75, 75);
            this.BtnMazoVisible.TabIndex = 1;
            this.BtnMazoVisible.UseVisualStyleBackColor = true;
            this.BtnMazoVisible.Click += new System.EventHandler(this.BtnMazoVisible_Click);
            // 
            // BtnReiniciar
            // 
            this.BtnReiniciar.BackColor = System.Drawing.Color.Goldenrod;
            this.BtnReiniciar.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReiniciar.Location = new System.Drawing.Point(619, 29);
            this.BtnReiniciar.Name = "BtnReiniciar";
            this.BtnReiniciar.Size = new System.Drawing.Size(152, 75);
            this.BtnReiniciar.TabIndex = 5;
            this.BtnReiniciar.Text = "Reiniciar";
            this.BtnReiniciar.UseVisualStyleBackColor = false;
            this.BtnReiniciar.Click += new System.EventHandler(this.BtnReinicio_Click);
            // 
            // BtnMetaA
            // 
            this.BtnMetaA.BackColor = System.Drawing.Color.LightSeaGreen;
            this.BtnMetaA.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMetaA.Location = new System.Drawing.Point(887, 29);
            this.BtnMetaA.Name = "BtnMetaA";
            this.BtnMetaA.Size = new System.Drawing.Size(75, 75);
            this.BtnMetaA.TabIndex = 6;
            this.BtnMetaA.Text = "A00";
            this.BtnMetaA.UseVisualStyleBackColor = false;
            this.BtnMetaA.MouseEnter += new System.EventHandler(this.BtnMeta_MouseEnter);
            // 
            // BtnMetaB
            // 
            this.BtnMetaB.BackColor = System.Drawing.Color.Crimson;
            this.BtnMetaB.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMetaB.Location = new System.Drawing.Point(992, 29);
            this.BtnMetaB.Name = "BtnMetaB";
            this.BtnMetaB.Size = new System.Drawing.Size(75, 75);
            this.BtnMetaB.TabIndex = 7;
            this.BtnMetaB.Text = "B00";
            this.BtnMetaB.UseVisualStyleBackColor = false;
            this.BtnMetaB.MouseEnter += new System.EventHandler(this.BtnMeta_MouseEnter);
            // 
            // BtnMetaC
            // 
            this.BtnMetaC.BackColor = System.Drawing.Color.LightSeaGreen;
            this.BtnMetaC.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMetaC.Location = new System.Drawing.Point(1101, 29);
            this.BtnMetaC.Name = "BtnMetaC";
            this.BtnMetaC.Size = new System.Drawing.Size(75, 75);
            this.BtnMetaC.TabIndex = 8;
            this.BtnMetaC.Text = "C00";
            this.BtnMetaC.UseVisualStyleBackColor = false;
            this.BtnMetaC.MouseEnter += new System.EventHandler(this.BtnMeta_MouseEnter);
            // 
            // BtnMetaD
            // 
            this.BtnMetaD.BackColor = System.Drawing.Color.Crimson;
            this.BtnMetaD.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMetaD.Location = new System.Drawing.Point(1214, 29);
            this.BtnMetaD.Name = "BtnMetaD";
            this.BtnMetaD.Size = new System.Drawing.Size(75, 75);
            this.BtnMetaD.TabIndex = 9;
            this.BtnMetaD.Text = "D00";
            this.BtnMetaD.UseVisualStyleBackColor = false;
            this.BtnMetaD.MouseEnter += new System.EventHandler(this.BtnMeta_MouseEnter);
            // 
            // LblMoves
            // 
            this.LblMoves.AutoSize = true;
            this.LblMoves.Font = new System.Drawing.Font("Consolas", 30F);
            this.LblMoves.Location = new System.Drawing.Point(259, 29);
            this.LblMoves.Name = "LblMoves";
            this.LblMoves.Size = new System.Drawing.Size(241, 59);
            this.LblMoves.TabIndex = 10;
            this.LblMoves.Text = "Moves: 0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1332, 653);
            this.Controls.Add(this.LblMoves);
            this.Controls.Add(this.BtnMetaD);
            this.Controls.Add(this.BtnMetaC);
            this.Controls.Add(this.BtnMetaB);
            this.Controls.Add(this.BtnMetaA);
            this.Controls.Add(this.BtnReiniciar);
            this.Controls.Add(this.BtnMazoVisible);
            this.Controls.Add(this.BtnMazo);
            this.Name = "Form1";
            this.Text = "Solitario";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnMazo;
        private System.Windows.Forms.Button BtnMazoVisible;
        private System.Windows.Forms.Button BtnReiniciar;
        private System.Windows.Forms.Button BtnMetaA;
        private System.Windows.Forms.Button BtnMetaB;
        private System.Windows.Forms.Button BtnMetaC;
        private System.Windows.Forms.Button BtnMetaD;
        private System.Windows.Forms.Label LblMoves;
    }
}

