﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Solitaire
{
    public partial class Form1 : Form
    {
        public string[] BarajaCompleta = new string[] {
        "A01", "A02", "A03", "A04", "A05", "A06", "A07", "A08", "A09", "A10", "A11", "A12", "A13",
        "B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B09", "B10", "B11", "B12", "B13",
        "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C08", "C09", "C10", "C11", "C12", "C13",
        "D01", "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10", "D11", "D12", "D13" };
        public string[] BarajaVisible = new string[0];
        public string[] ColumnasText = new string[7];

        public Button[] Col1 = new Button[0];
        public Button[] Col2 = new Button[0];
        public Button[] Col3 = new Button[0];
        public Button[] Col4 = new Button[0];
        public Button[] Col5 = new Button[0];
        public Button[] Col6 = new Button[0];
        public Button[] Col7 = new Button[0];

        public Button Highed;
        public string Mover;
        public int MovLeng;
        public int MovCol;
        public int Movimientos=0;

        Timer t = null;
        private void StartTimer()
        {
            t = new Timer();
            t.Interval = 500;
            t.Tick += new EventHandler(t_Tick);
            t.Enabled = true;
        }

        void t_Tick(object sender, EventArgs e)
        {
            if(BtnReiniciar.BackColor == Color.Crimson)
            {
                BtnReiniciar.BackColor = Color.Goldenrod;
                BtnMetaA.BackColor = Color.Goldenrod;
                BtnMetaB.BackColor = Color.Goldenrod;
                BtnMetaC.BackColor = Color.Goldenrod;
                BtnMetaD.BackColor = Color.Goldenrod;
            }
            else if(BtnReiniciar.BackColor==Color.Goldenrod)
            {
                BtnReiniciar.BackColor = Color.LightSeaGreen;
                BtnMetaA.BackColor = Color.LightSeaGreen;
                BtnMetaB.BackColor = Color.LightSeaGreen;
                BtnMetaC.BackColor = Color.LightSeaGreen;
                BtnMetaD.BackColor = Color.LightSeaGreen;
            }
            else if(BtnReiniciar.BackColor==Color.LightSeaGreen)
            {
                BtnReiniciar.BackColor = Color.Crimson;
                BtnMetaA.BackColor = Color.Crimson;
                BtnMetaB.BackColor = Color.Crimson;
                BtnMetaC.BackColor = Color.Crimson;
                BtnMetaD.BackColor = Color.Crimson;
            }
        }

        public Form1()
        {
            InitializeComponent();
            Repartir();
        }
        public void Repartir()
        {
            Random R = new Random();
            foreach (string K in BarajaCompleta)
            {
                int B = R.Next(0, BarajaCompleta.Length);
                string A = K;
                BarajaCompleta[Array.IndexOf(BarajaCompleta, K)] = BarajaCompleta[B];
                BarajaCompleta[B] = A;
            }

            for (int i = 0; i < ColumnasText.Length; i++) //Poner cartas en las columnas
            {
                for (int x = 0; x <= i; x++)
                {
                    ColumnasText[i] += BarajaCompleta[BarajaCompleta.Length - 1];
                    Array.Resize(ref BarajaCompleta, BarajaCompleta.Length - 1);
                    Button btn = new Button();
                    this.Controls.Add(btn); 
                    btn.Size = new Size(75,50);
                    btn.Location = new Point(30 + (145 * i), 125 + (50 * x));
                    btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                    btn.MouseEnter += BtnColumna_MouseEnter;
                    btn.MouseClick += BtnCol_Click;
                    btn.Text = ColumnasText[i].Substring(ColumnasText[i].Length - 3, 3);
                    btn.Font = new Font("Consolas", 1);
                    btn.BackColor = Color.Silver;
                    btn.ForeColor = Color.Black;
                    btn.Enabled = false;
                    if (x == i)
                    {
                        btn.Font = new Font("Consolas", 20);
                        btn.Text = ColumnasText[i].Substring(ColumnasText[i].Length - 3);
                        Colore(btn);
                        btn.Enabled = true;
                        btn.Visible = true;
                    }
                    switch(i)
                    {
                        case 0:
                            {
                                Array.Resize(ref Col1, Col1.Length+1);
                                Col1[Col1.Length - 1] = btn;
                                break;
                            }
                        case 1:
                            {
                                Array.Resize(ref Col2, Col2.Length + 1);
                                Col2[Col2.Length - 1] = btn;
                                break;
                            }
                        case 2:
                            {
                                Array.Resize(ref Col3, Col3.Length + 1);
                                Col3[Col3.Length - 1] = btn;
                                break;
                            }
                        case 3:
                            {
                                Array.Resize(ref Col4, Col4.Length + 1);
                                Col4[Col4.Length - 1] = btn;
                                break;
                            }
                        case 4:
                            {
                                Array.Resize(ref Col5, Col5.Length + 1);
                                Col5[Col5.Length - 1] = btn;
                                break;
                            }
                        case 5:
                            {
                                Array.Resize(ref Col6, Col6.Length + 1);
                                Col6[Col6.Length - 1] = btn;
                                break;
                            }
                        case 6:
                            {
                                Array.Resize(ref Col7, Col7.Length + 1);
                                Col7[Col7.Length - 1] = btn;
                                break;
                            }
                    }
                }
            }
        }
        /*
        private void BtnCompleta_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Baraja Completa:" + BarajaCompleta.Length);
            foreach (string A in BarajaCompleta)
            {
                Console.WriteLine(A);
            }
        }
        private void BtnVisible_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Baraja Visible:" + BarajaVisible.Length);
            foreach (string A in BarajaVisible)
            {
                Console.WriteLine(A);
            }
            if(Highed!=null)
            {
                Console.WriteLine(Highed + "-" + Highed.Text);
            }
        }
        private void BtnColumnas_Click(object sender, EventArgs e)
        {
            foreach (string ala in ColumnasText)
            {
                Console.WriteLine(ala);
            }
        }
        private void BtnColSize_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Col sizes");
            Console.WriteLine(Col1.Length);
            Console.WriteLine(Col2.Length);
            Console.WriteLine(Col3.Length);
            Console.WriteLine(Col4.Length); 
            Console.WriteLine(Col5.Length);
            Console.WriteLine(Col6.Length); 
            Console.WriteLine(Col7.Length);
        }
        */
        private void BtnReinicio_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
        private void BtnMazo_Click(object sender, EventArgs e)
        {
            if (Highed == null)
            {
                
                if (BarajaCompleta.Length == 0)
                {
                    Array.Reverse(BarajaVisible);
                    Array.Resize(ref BarajaCompleta, BarajaVisible.Length);
                    BarajaCompleta = BarajaVisible;
                    Array.Resize(ref BarajaVisible, 0);
                }
                if(BarajaCompleta.Length>0)
                {
                    Movimientos++;
                    LblMoves.Text = "Moves: " + Movimientos;
                    string Carta = BarajaCompleta[BarajaCompleta.Length - 1];
                    if (BarajaVisible.Contains(Carta)) { }
                    else
                    {
                        Console.WriteLine(Carta);
                        Array.Resize(ref BarajaVisible, BarajaVisible.Length + 1);
                        BarajaVisible[BarajaVisible.Length - 1] = Carta;
                        Array.Resize(ref BarajaCompleta, BarajaCompleta.Length - 1);
                    }
                    BtnMazoVisible.Enabled = true;
                    BtnMazoVisible.Text = BarajaVisible[BarajaVisible.Length - 1];
                    Colore(BtnMazoVisible);
                }
                
            }
        }
        private void BtnMazoVisible_Click(object sender, EventArgs e)
        {
            if (BarajaVisible.Length > 0)
            {
                Button btn = (Button)sender;
                Console.WriteLine(btn.Text/*.Substring(btn.Text.Length - 3, 1)*/);
                High(btn);
            }
        }
        private void BtnCol_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            High(btn);
        }
        public void CrearBoton(int i, int x, string T)
        {
            Button btna = new Button();
            btna.Size = new Size(75,50) ;
            btna.Location = new Point(30 + (145 * i), 125 + (50 * x));
            Console.WriteLine(BtnMazo.Size.Height);
            btna.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            btna.MouseEnter += BtnColumna_MouseEnter;
            btna.MouseClick += BtnCol_Click;
            btna.Text = T;// ColumnasText[i].Substring(ColumnasText[i].Length - 3);
            btna.Font = new Font("Consolas", 20);
            this.Controls.Add(btna);
            btna.BringToFront();
            Colore(btna);
            if(T!=" ")
            {
                switch (i)
                {
                    case 0:
                        {
                            Array.Resize(ref Col1, Col1.Length + 1);
                            Col1[Col1.Length - 1] = btna;
                            break;
                        }
                    case 1:
                        {
                            Array.Resize(ref Col2, Col2.Length + 1);
                            Col2[Col2.Length - 1] = btna;
                            break;
                        }
                    case 2:
                        {
                            Array.Resize(ref Col3, Col3.Length + 1);
                            Col3[Col3.Length - 1] = btna;
                            break;
                        }
                    case 3:
                        {
                            Array.Resize(ref Col4, Col4.Length + 1);
                            Col4[Col4.Length - 1] = btna;
                            break;
                        }
                    case 4:
                        {
                            Array.Resize(ref Col5, Col5.Length + 1);
                            Col5[Col5.Length - 1] = btna;
                            break;
                        }

                    case 5:
                        {
                            Array.Resize(ref Col6, Col6.Length + 1);
                            Col6[Col6.Length - 1] = btna;
                            break;
                        }
                    case 6:
                        {
                            Array.Resize(ref Col7, Col7.Length + 1);
                            Col7[Col7.Length - 1] = btna;
                            break;
                        }
                }
            }
            
        }
        public void High(Button J)
        {
            if ((J.BackColor == Color.Crimson || J.BackColor == Color.LightSeaGreen) && Highed == null)
            {
                Movimientos++;
                LblMoves.Text = "Moves: " + Movimientos;
                J.BackColor = Color.Goldenrod;
                Highed = J;
            }
            else if (Highed == J)
            {
                Highed = null;
                if (J.Text.Contains("A") || J.Text.Contains("C"))
                {
                    J.BackColor = Color.LightSeaGreen;
                }
                else
                {
                    J.BackColor = Color.Crimson;
                }
            }
            if(Highed!=null)
            {
                if (Highed.Text.Contains("13"))
                {
                    for (int i = 0; i < ColumnasText.Length; i++)
                    {
                        if (ColumnasText[i].Length == 0)
                        {
                            if (BarajaVisible.Contains(Highed.Text))
                            {
                                Movimientos++;
                                LblMoves.Text = "Moves: " + Movimientos;
                                ColumnasText[i] += Highed.Text;
                                CrearBoton(i, 0, Highed.Text);
                                BarajaVisible[BarajaVisible.Length - 1] = null;
                                Array.Resize(ref BarajaVisible, BarajaVisible.Length - 1);
                                if (BarajaVisible.Length > 0)
                                {
                                    BtnMazoVisible.Text = BarajaVisible[BarajaVisible.Length - 1];
                                }
                                else
                                {
                                    BtnMazoVisible.Text = "";
                                }
                                Colore(BtnMazoVisible);
                                Highed = null;
                            }
                            break;
                        }
                    }
                }
            }
            
        }
        public void Colore(Button K)
        {
            if (K.Text.Contains("A") || K.Text.Contains("C"))
            {
                K.BackColor = Color.LightSeaGreen;
            }
            else if (K.Text.Contains("B") || K.Text.Contains("D"))
            {
                K.BackColor = Color.Crimson;
            }
            else
            {
                K.BackColor = Color.Silver;
            }
        }
        public void CM(int i, int jj)
        {
            switch (i)
            {
                case 0:
                    {
                        for(int a=1;a<=jj;a++)
                        {
                            Col1[Col1.Length - a].Visible = false;
                            Col1[Col1.Length - a].Enabled = false;
                            Col1[Col1.Length - a] = null;
                        }
                        Array.Resize(ref Col1, Col1.Length - jj);
                        if(Col1.Length>0)
                        {
                            Col1[Col1.Length-1].Font = new Font("Consolas", 20);
                            Col1[Col1.Length - 1].Enabled = true;
                            Colore(Col1[Col1.Length - 1]);
                        }
                        else
                        {
                            CrearBoton(i, 0, " ");
                        }
                        break;
                    }
                case 1:
                    {
                        for (int a = 1; a <= jj; a++)
                        {
                            Col2[Col2.Length - a].Visible = false;
                            Col2[Col2.Length - a].Enabled = false;
                            Col2[Col2.Length - a] = null;
                        }
                        Array.Resize(ref Col2, Col2.Length - jj);
                        if (Col2.Length > 0)
                        {
                            Col2[Col2.Length - 1].Font = new Font("Consolas", 20);

                            Col2[Col2.Length - 1].Enabled = true;
                            Colore(Col2[Col2.Length - 1]);
                        }
                        else
                        {
                            CrearBoton(i, 0, " ");
                        }
                        break;
                    }
                case 2:
                    {
                        for (int a = 1; a <= jj; a++)
                        {
                            Col3[Col3.Length - a].Visible = false;
                            Col3[Col3.Length - a].Enabled = false;
                            Col3[Col3.Length - a] = null;
                        }
                        Array.Resize(ref Col3, Col3.Length - jj);
                        if (Col3.Length > 0)
                        {
                            Col3[Col3.Length - 1].Font = new Font("Consolas", 20);

                            Col3[Col3.Length - 1].Enabled = true;
                            Colore(Col3[Col3.Length - 1]);
                        }
                        else
                        {
                            CrearBoton(i, 0, " ");
                        }
                        break;
                    }
                case 3:
                    {
                        for (int a = 1; a <= jj; a++)
                        {
                            Col4[Col4.Length - a].Visible = false;
                            Col4[Col4.Length - a].Enabled = false;
                            Col4[Col4.Length - a] = null;
                        }
                        Array.Resize(ref Col4, Col4.Length - jj);
                        if (Col4.Length > 0)
                        {
                            Col4[Col4.Length - 1].Font = new Font("Consolas", 20);

                            Col4[Col4.Length - 1].Enabled = true;
                            Colore(Col4[Col4.Length - 1]);
                        }
                        else
                        {
                            CrearBoton(i, 0, " ");
                        }
                        break;
                    }
                case 4:
                    {
                        for (int a = 1; a <= jj; a++)
                        {
                            Col5[Col5.Length - a].Visible = false;
                            Col5[Col5.Length - a].Enabled = false;
                            Col5[Col5.Length - a] = null;
                        }
                        Array.Resize(ref Col5, Col5.Length - jj);
                        if (Col5.Length > 0)
                        {
                            Col5[Col5.Length - 1].Font = new Font("Consolas", 20);

                            Col5[Col5.Length - 1].Enabled = true;
                            Colore(Col5[Col5.Length - 1]);
                        }
                        else
                        {
                            CrearBoton(i, 0, " ");
                        }
                        break;
                    }
                case 5:
                    {
                        for (int a = 1; a <= jj; a++)
                        {
                            Col6[Col6.Length - a].Visible = false;
                            Col6[Col6.Length - a].Enabled = false;
                            Col6[Col6.Length - a] = null;
                        }
                        Array.Resize(ref Col6, Col6.Length - jj);
                        if (Col6.Length > 0)
                        {
                            Col6[Col6.Length - 1].Font = new Font("Consolas", 20);

                            Col6[Col6.Length - 1].Enabled = true;
                            Colore(Col6[Col6.Length - 1]);
                        }
                        else
                        {
                            CrearBoton(i, 0, " ");
                        }
                        break;
                    }
                case 6:
                    {
                        for (int a = 1; a <= jj; a++)
                        {
                            Col7[Col7.Length - a].Visible = false;
                            Col7[Col7.Length - a].Enabled = false;
                            Col7[Col7.Length - a] = null;
                        }
                        Array.Resize(ref Col7, Col7.Length - jj);
                        if (Col7.Length > 0)
                        {
                            Col7[Col7.Length - 1].Font = new Font("Consolas", 20);

                            Col7[Col7.Length - 1].Enabled = true;
                            Colore(Col7[Col7.Length - 1]);
                        }
                        else
                        {
                            CrearBoton(i, 0, " ");
                        }
                        break;
                    }
            }
        }
        public void CMET(int i)
        {
            CME();
            Console.WriteLine("MovCol:" + MovCol);
            Console.WriteLine("MovLeng:" + MovLeng);
            Console.WriteLine("i:" + i);
            ColumnasText[i] += Mover;
            int x = ColumnasText[i].Length / 3;
            Console.WriteLine("x:" + x);
            for(int k=0;k<MovLeng;k++)
            {
                CrearBoton(i, x-MovLeng+(k), Mover.Substring(k*3,3));
            }
            CM(MovCol, MovLeng);
            Highed = null;
        }
        public void CME() //Columna de la que se va a mover
        {
            for (int z = 0; z < ColumnasText.Length; z++)
            {
                for (int j = 0; j < ColumnasText[z].Length;j+=3)
                {
                    if (ColumnasText[z].Length > 0)
                    {
                        if (ColumnasText[z].Substring(ColumnasText[z].Length - (j+3), 3).Contains(Highed.Text))
                        {
                            Mover = ColumnasText[z].Substring(ColumnasText[z].Length - (j + 3), j + 3);
                            ColumnasText[z] = ColumnasText[z].Substring(0, ColumnasText[z].Length - (j + 3));
                            MovLeng = Mover.Length / 3;
                            MovCol = z;
                            z =+ 10;
                            break;
                        }
                    }
                }
            }
        }
        private void BtnColumna_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if(Highed!=null)
            {
                if (BarajaVisible.Contains(Highed.Text))
                {
                    if ((((btn.Text.Contains("A") || btn.Text.Contains("C")) &&
                    (Highed.Text.Contains("B") || Highed.Text.Contains("D"))) &&
                    int.Parse(btn.Text.Substring(1, 2)) == int.Parse(Highed.Text.Substring(1, 2)) + 1) ||
                    (((btn.Text.Contains("B") || btn.Text.Contains("D")) &&
                    (Highed.Text.Contains("A") || Highed.Text.Contains("C"))) &&
                    int.Parse(btn.Text.Substring(1, 2)) == int.Parse(Highed.Text.Substring(1, 2)) + 1))
                    {
                        for(int a=0;a<ColumnasText.Length;a++)
                        {
                            if(ColumnasText[a].Length>0)
                            {
                                if (btn.Text == ColumnasText[a].Substring(ColumnasText[a].Length - 3, 3))
                                {
                                    string T = Highed.Text;
                                    BarajaVisible[BarajaVisible.Length - 1] = null;
                                    Array.Resize(ref BarajaVisible, BarajaVisible.Length - 1);
                                    if (BarajaVisible.Length > 0)
                                    {
                                        BtnMazoVisible.Text = BarajaVisible[BarajaVisible.Length - 1];
                                    }
                                    else
                                    {
                                        BtnMazoVisible.Text = "";
                                    }
                                    for (int i = 0; i < ColumnasText.Length; i++)
                                    {
                                        if (ColumnasText[i].Contains(btn.Text))
                                        {
                                            ColumnasText[i] += T;
                                            int x = ColumnasText[i].Length / 3;
                                            CrearBoton(i, x - 1, T);
                                        }
                                    }
                                    Colore(BtnMazoVisible);
                                    Highed = null;
                                }
                            }
                        }
                    }
                    else if(btn.Text==" " && Highed.Text.Contains("13"))
                    {
                        Console.WriteLine("13 empty");
                        for(int i=0;i<ColumnasText.Length;i++)
                        {

                        }
                    }
                }
                for (int i = 0; i < ColumnasText.Length; i++)
                {
                    if (ColumnasText[i].Length>0)
                    {
                        if (ColumnasText[i].Substring(ColumnasText[i].Length - 3, 3) == btn.Text && Highed!=null)
                        {
                            if (((btn.Text.Contains("A") || btn.Text.Contains("C")) &&
                            (Highed.Text.Contains("B") || Highed.Text.Contains("D"))) &&
                            int.Parse(btn.Text.Substring(1, 2)) == int.Parse(Highed.Text.Substring(1, 2)) + 1)
                            {
                                CMET(i);
                                break;
                            }
                            else if (((btn.Text.Contains("B") || btn.Text.Contains("D")) &&
                            (Highed.Text.Contains("A") || Highed.Text.Contains("C"))) &&
                            int.Parse(btn.Text.Substring(1, 2)) == int.Parse(Highed.Text.Substring(1, 2)) + 1)
                            {
                                CMET(i);
                                break;
                            }
                        }
                    }
                    else if (btn.Text == " " && Highed.Text.Contains("13"))
                    {
                        Console.WriteLine("13 empty");
                        CMET(i);
                        break;
                    }
                }
            }
        }
        private void BtnMeta_MouseEnter(object sender, EventArgs e)
        {
            //DIO's Mansion
            Button btn = (Button)sender;
            if(Highed!=null)
            {
                if(int.Parse(btn.Text.Substring(1,2))==int.Parse(Highed.Text.Substring(1,2))-1 &&
                    btn.Text.Substring(0,1) == Highed.Text.Substring(0,1) )
                {
                    string T = Highed.Text;
                    if (BarajaVisible.Contains(Highed.Text))
                       {
                       btn.Text = T;
                       BarajaVisible[BarajaVisible.Length - 1] = null;
                       Array.Resize(ref BarajaVisible, BarajaVisible.Length - 1);
                       if (BarajaVisible.Length > 0)
                       {
                           BtnMazoVisible.Text = BarajaVisible[BarajaVisible.Length - 1];
                       }
                       else
                       {
                           BtnMazoVisible.Text = "";
                       }
                       Colore(BtnMazoVisible);
                       Highed = null;
                    }
                    else if(Highed!=null)
                    {
                        for (int i = 0; i < ColumnasText.Length; i++)
                        {
                            if(ColumnasText[i].Length>0)
                            {
                                if (ColumnasText[i].Substring(ColumnasText[i].Length - 3, 3) == T)
                                {
                                    Console.WriteLine("AJA");
                                    btn.Text = T;
                                    CM(i, 1);
                                    ColumnasText[i] = ColumnasText[i].Substring(0, ColumnasText[i].Length - 3);
                                    Highed = null;
                                    break;
                                }
                            }
                        }
                    }
                     
                }
            }
            Victoria();
        }

        public void Victoria()
        {
            if(BtnMetaA.Text=="A13" && BtnMetaB.Text=="B13" && BtnMetaC.Text=="C13" && BtnMetaD.Text=="D13")
            {
                BtnMazo.Enabled = false;
                BtnMazoVisible.Enabled = false;
                StartTimer();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
