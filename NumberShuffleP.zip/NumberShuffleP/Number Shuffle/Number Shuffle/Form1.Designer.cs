﻿namespace Number_Shuffle
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BtnGenerar = new System.Windows.Forms.Button();
            this.CbxSize = new System.Windows.Forms.ComboBox();
            this.lblTimer = new System.Windows.Forms.Label();
            this.BtnGauntlet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnGenerar
            // 
            this.BtnGenerar.BackColor = System.Drawing.Color.Pink;
            this.BtnGenerar.FlatAppearance.BorderColor = System.Drawing.Color.Chocolate;
            this.BtnGenerar.FlatAppearance.BorderSize = 2;
            this.BtnGenerar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnGenerar.Font = new System.Drawing.Font("Consolas", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGenerar.ForeColor = System.Drawing.Color.Chocolate;
            this.BtnGenerar.Location = new System.Drawing.Point(30, 200);
            this.BtnGenerar.Name = "BtnGenerar";
            this.BtnGenerar.Size = new System.Drawing.Size(225, 50);
            this.BtnGenerar.TabIndex = 0;
            this.BtnGenerar.Text = "Iniciar";
            this.BtnGenerar.UseVisualStyleBackColor = false;
            this.BtnGenerar.Click += new System.EventHandler(this.BtnGenerar_Click);
            // 
            // CbxSize
            // 
            this.CbxSize.BackColor = System.Drawing.Color.Pink;
            this.CbxSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxSize.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CbxSize.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CbxSize.ForeColor = System.Drawing.Color.Chocolate;
            this.CbxSize.FormattingEnabled = true;
            this.CbxSize.Items.AddRange(new object[] {
            "3x3",
            "4x4",
            "5x5",
            "6x6",
            "7x7",
            "8x8",
            "9x9"});
            this.CbxSize.Location = new System.Drawing.Point(90, 70);
            this.CbxSize.Name = "CbxSize";
            this.CbxSize.Size = new System.Drawing.Size(80, 40);
            this.CbxSize.TabIndex = 1;
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.BackColor = System.Drawing.Color.Pink;
            this.lblTimer.Font = new System.Drawing.Font("Consolas", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.ForeColor = System.Drawing.Color.Chocolate;
            this.lblTimer.Location = new System.Drawing.Point(28, 267);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(214, 51);
            this.lblTimer.TabIndex = 2;
            this.lblTimer.Text = "00:00:00";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnGauntlet
            // 
            this.BtnGauntlet.BackColor = System.Drawing.Color.Pink;
            this.BtnGauntlet.FlatAppearance.BorderColor = System.Drawing.Color.Chocolate;
            this.BtnGauntlet.FlatAppearance.BorderSize = 2;
            this.BtnGauntlet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnGauntlet.Font = new System.Drawing.Font("Consolas", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGauntlet.ForeColor = System.Drawing.Color.Chocolate;
            this.BtnGauntlet.Location = new System.Drawing.Point(30, 132);
            this.BtnGauntlet.Name = "BtnGauntlet";
            this.BtnGauntlet.Size = new System.Drawing.Size(225, 50);
            this.BtnGauntlet.TabIndex = 4;
            this.BtnGauntlet.Text = "Gauntlet";
            this.BtnGauntlet.UseVisualStyleBackColor = false;
            this.BtnGauntlet.Click += new System.EventHandler(this.BtnGauntlet_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Number_Shuffle.Properties.Resources.download;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(282, 453);
            this.Controls.Add(this.BtnGauntlet);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.CbxSize);
            this.Controls.Add(this.BtnGenerar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Number Shuffle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnGenerar;
        private System.Windows.Forms.ComboBox CbxSize;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button BtnGauntlet;
    }
}

