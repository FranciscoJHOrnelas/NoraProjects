﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Number_Shuffle
{
    public partial class Form1 : Form
    {
        public DateTime mdate = DateTime.Now;
        //public DateTime mdate = DateTime.Parse("5:10");
        public int[] Numeros = new int[0];
        public int[] Inpar = new int[0];
        public int[] Par = new int[0];
        public Button[] Botones = new Button[0];
        public bool Gauntlet = false;
        public Button Highed;
        Timer t = null;

        private void StartTimer()
        {
            t = new Timer();
            t.Interval = 1000;
            t.Tick += new EventHandler(t_Tick);
            t.Enabled = true;
        }
        void t_Tick(object sender, EventArgs e)
        {
            TimeSpan ts = DateTime.Now.Subtract(mdate);
            lblTimer.Text = string.Format("{0:00}:{1:00}:{2:00}", (int)ts.Hours, (int)ts.Minutes, (int)ts.Seconds);
            //lblTimer.Text = string.Format("{00:00}:{1:00}", (int)ts.Minutes, ts.Seconds);
        }
        public Form1()
        {
            InitializeComponent();
            CbxSize.SelectedIndex = 1;
        }
        private void BtnGenerar_Click(object sender, EventArgs e)
        {
            if(BtnGenerar.Text=="Reiniciar" && !Gauntlet)
            {
                Application.Restart();
            }
            if (!Gauntlet) { BtnGenerar.Text = "Reiniciar"; }
            int S = CbxSize.SelectedIndex + 3;
            this.Size = new Size(300 + (S * 75), 200+(S*75));
            //BtnGenerar.Enabled = false;
            //BtnGenerar.BackColor = Color.Silver;
            CbxSize.Enabled = false;
            CbxSize.BackColor = Color.Silver;
            BtnGauntlet.Enabled = false;
            BtnGauntlet.BackColor = Color.Silver;
            NotSolvable:
            Array.Resize(ref Numeros, 0);
            Array.Resize(ref Numeros, (S*S));
            Array.Resize(ref Botones, Numeros.Length);
            bool ParInpar=(S%2==0);
            for(int i=1;i<=Numeros.Length;i++)
            {
                if(i<Numeros.Length)
                {
                    Numeros[i - 1] = i;
                }
                if (ParInpar)
                {
                    Array.Resize(ref Par, Par.Length + 1);
                    Par[Par.Length - 1] = Array.IndexOf(Numeros, i);
                }
                else
                {
                    Array.Resize(ref Inpar, Inpar.Length + 1);
                    Inpar[Inpar.Length - 1] = Array.IndexOf(Numeros, i);
                }
                if((i)%S==0)
                {
                    ParInpar = !ParInpar;
                }
                //Console.WriteLine(Numeros[i-1]);
            }
            if(Par.Contains(-1))
            {
                Par[Array.IndexOf(Par, -1)] = Numeros.Length - 1;
            }
            else if(Inpar.Contains(-1))
            {
                Inpar[Array.IndexOf(Inpar, -1)] = Numeros.Length - 1;
            }
            Random Rand = new Random();
            for (int i=1;i<Numeros.Length;i++)
            {
                int N = Rand.Next(0, Numeros.Length);
                int aa = Numeros[N];
                Numeros[N] = Numeros[i-1];
                Numeros[i-1] = aa;
                
                //Console.WriteLine(Numeros[i - 1]);
            }
            /*
            for (int i = 1; i <= Numeros.Length; i++)
            {
                Console.WriteLine(Numeros[i-1] + "-"+ (i-1));
            }
            
            Console.WriteLine("Par");
            for(int i=0; i<Par.Length;i++)
            {
                Console.WriteLine(Par[i]);
            }

            Console.WriteLine("inPar");
            for (int i = 0; i < Inpar.Length; i++)
            {
                Console.WriteLine(Inpar[i]);
            }*/

            int M = 0;
            for(int i=0;i<Numeros.Length;i++)
            {
                for(int j=0;j<Numeros.Length;j++)
                {
                    if(Numeros[i]>Numeros[j] && Numeros[j]!=0 && j>i)
                    {
                        M++;
                        //Console.WriteLine("i" +Numeros[i]);
                        //Console.WriteLine("j" +Numeros[j]);
                        //Console.WriteLine("m" + M);
                    }
                }
            }
            if (S % 2 == 0)
            {
                if ((Par.Contains(Array.IndexOf(Numeros,0)) && (M % 2 == 1)) ||
                   ((Inpar.Contains(Array.IndexOf(Numeros,0)) && (M % 2 == 0))))
                {
                    Console.WriteLine("Solvable"+M);
                }
                else
                {
                    Console.WriteLine("Not Solvable");
                    goto NotSolvable;
                }
            }
            else if(S%2==1 && M%2==0)
            {
                Console.WriteLine("Solvable" + M);
            }
            else
            {
                Console.WriteLine("Not Solvable");
                goto NotSolvable;
            }

            for (int i=0;i<S;i++)
            {
                for(int R=0;R<S;R++)
                {

                        Button btn = new Button();
                    if (Numeros[(i * S) + R] != 0)
                    {
                        this.Controls.Add(btn);
                    }
                        btn.BackColor = Color.Chocolate;
                        btn.Text = Numeros[(i * S) + R].ToString();
                        btn.Size = new Size(75, 75);
                        btn.Location = new Point(200 + (75 * R), 50 + (75 * i));
                        btn.Font = new Font("Consolas", 20);
                        btn.MouseClick += BtnTablero_Click;
                        Botones[(i * S) + R] = btn;
                }
            }
            StartTimer();

        }
        public void CrearBoton(int Index, int btnIndex)
        {
            int R = Index % (CbxSize.SelectedIndex + 3);
            int i = Index / (CbxSize.SelectedIndex + 3);
            Button btn = new Button();
            this.Controls.Add(btn);
            btn.BackColor = Color.Chocolate;
            btn.Text = Numeros[btnIndex].ToString();
            btn.Size = new Size(75, 75);
            btn.Location = new Point(200 + (75 * R), 50 + (75 * i));
            btn.Font = new Font("Consolas", 20);
            btn.MouseClick += BtnTablero_Click;
            Array.Resize(ref Botones, Botones.Length + 1);
            Botones[Botones.Length - 1]=btn;
        }
        public void Victoria()
        {
            int C = 1;
            for (int i = 0; i < Numeros.Length - 1; i++)
            {
                //Console.WriteLine(i);
                //Console.WriteLine(Numeros[i]);
                if (Numeros[i] == i + 1)
                {
                    C++;

                }
                else
                {
                    foreach(Button btn in Botones)
                    {
                        btn.ForeColor = Color.Black;
                        btn.BackColor = Color.Chocolate;
                        if (btn.Text==C.ToString())
                        {
                            btn.ForeColor = Color.Gold;
                            btn.BackColor = Color.Firebrick;
                        }
                    }
                    C = 1;
                    break;
                }
                Console.WriteLine("C" + C);
            }
            if (C == Numeros.Length)
            {
                int K = (CbxSize.SelectedIndex + 3) * (CbxSize.SelectedIndex + 3);
                Console.WriteLine("Ganaste");
                //Console.WriteLine(Botones.Length);
                t.Enabled = false;
                lblTimer.BackColor = Color.Silver;
                foreach(Button btn in Botones)
                {
                    btn.Enabled = false;
                    btn.BackColor = Color.Silver;
                }
                CrearBoton(K-1, K-1);
                Botones[Botones.Length - 1].Text = K.ToString();
                Botones[Botones.Length - 1].Enabled = false;
                Botones[Botones.Length - 1].BackColor = Color.Silver;
                if(Gauntlet)
                {
                    foreach (Button btn in Botones)
                    {
                        btn.Visible = false;
                        btn.Dispose();
                    }
                    lblTimer.BackColor = Color.Pink;
                    Botones[Botones.Length - 1].Visible = false;
                    Array.Resize(ref Botones, 0);
                    Array.Resize(ref Par, 0);
                    Array.Resize(ref Inpar, 0);
                    GeneraLabelTime(CbxSize.SelectedIndex + 1);
                    //GeneraLabelGrid(CbxSize.SelectedIndex + 1);
                    CbxSize.SelectedIndex += 1;
                    //Console.WriteLine(Botones.Length);
                    EventArgs e = new EventArgs();
                    BtnGenerar_Click(BtnGenerar, e);
                }
            }
        }
        public void GeneraLabelTime(int O)
        {
            Label lbl = new Label();
            lbl.Text = lblTimer.Text + " " + CbxSize.SelectedItem.ToString();
            lbl.Location = new Point(30, 200+(75*O));
            lbl.AutoSize = false;
            lbl.Font = new Font("Consolas", 20);
            lbl.Size = new Size(150,75);
            lbl.BackColor = lblTimer.BackColor;
            lbl.ForeColor = lblTimer.ForeColor;
            lbl.TextAlign = ContentAlignment.MiddleCenter;
            this.Controls.Add(lbl);
        }
        /*public void GeneraLabelGrid(int O)
        {
            Label lbl = new Label();
            lbl.Text = CbxSize.SelectedItem.ToString();
            lbl.Location = new Point(lblTimer.Location.X, lblTimer.Location.Y + (25 * O));
            lbl.Font = lblTimer.Font;
            lbl.Size = lblTimer.Size;
            lbl.BackColor = lblTimer.BackColor;
            lbl.ForeColor = lblTimer.ForeColor;
            lbl.TextAlign = ContentAlignment.MiddleCenter;
            this.Controls.Add(lbl);
        }*/
        private void BtnTablero_Click(object sender, EventArgs e)
        {
            Console.WriteLine(Botones.Length);
            Button btn = (Button)sender;
            //Console.WriteLine(btn.Text);
            int btnIndex = Array.IndexOf(Numeros, int.Parse(btn.Text));
            //Console.WriteLine(btnIndex);
            int ZIndex = Array.IndexOf(Numeros, 0);
            //Console.WriteLine(ZIndex);
            if((btnIndex+1==ZIndex && ZIndex%int.Parse(CbxSize.SelectedItem.ToString().Substring(0,1))!=0) || 
               (btnIndex-1==ZIndex && btnIndex % int.Parse(CbxSize.SelectedItem.ToString().Substring(0, 1)) != 0) ||
               (btnIndex+CbxSize.SelectedIndex+3==ZIndex) || (btnIndex - (CbxSize.SelectedIndex + 3) == ZIndex))
            {
                btn.Visible=false;
                Botones[Array.IndexOf(Botones, btn)].Visible =false;
                //btn.Dispose();
                //this.Controls.Remove(sender);
                CrearBoton(ZIndex, btnIndex);
                Numeros[ZIndex] = Numeros[btnIndex];
                Numeros[btnIndex] = 0;
                Victoria();

            }
            foreach (Button bt in Botones)
            {
                if(bt.Visible ==false)
                {
                    Botones[Array.IndexOf(Botones, bt)] = Botones[Botones.Length-1];
                    Array.Resize(ref Botones, Botones.Length - 1);
                }
                else
                {
                    Console.WriteLine(bt.Text);
                }
            }

        }
        private void BtnGauntlet_Click(object sender, EventArgs e)
        {
            CbxSize.SelectedIndex = 0;
            Gauntlet = true;
            BtnGenerar_Click(BtnGenerar, e);
            BtnGenerar.Enabled = false;
            BtnGenerar.BackColor = Color.Silver;
            BtnGenerar.Text = "???????";
        }
    }
}