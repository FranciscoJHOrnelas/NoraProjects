﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Buscaminas
{
    public partial class Form1 : Form
    {

        public DateTime mdate = DateTime.Now;

        int[] pos = new int[0];
        Button[] Bombas = new Button[0];
        int[] Vecinotl = new int[0];
        //int[,] Vecinos = new int[12,8];
        GroupBox gbxTablero = new GroupBox();
        public int Flags=0;

        public Form1()
        {
            InitializeComponent();
            CbxSize.SelectedIndex = 0;
            CbxMinas.SelectedIndex = 0;
        }

        Timer t = null;
        private void StartTimer()
        {
            t = new Timer();
            t.Interval = 1000;
            t.Tick += new EventHandler(t_Tick);
            t.Enabled = true;
        }

        void t_Tick(object sender, EventArgs e)
        {
            TimeSpan ts = DateTime.Now.Subtract(mdate);

            //lblTimer.Text = ts.Minutes.ToString("") + ":" + ts.Seconds.ToString("");
            lblTimer.Text = string.Format("{00:00}:{1:00}",(int)ts.Minutes,ts.Seconds);
        }
        private void BtnGenerar_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Array.Resize(ref pos, int.Parse(CbxSize.Text) * (3));
            Array.Resize(ref Bombas, int.Parse(CbxSize.Text) * (3));

            btn.Enabled = false;
            
            CbxMinas.Enabled = false;
            CbxSize.Enabled = false;

            /*
            for (int i = 0; i < Bombas.Length; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Vecinos[i, j] = 100;
                }
            }
            */

            GenerarTablero();
            StartTimer();
        }
        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public void GenerarTablero()
        {
            gbxTablero.Size = new Size(50 + (int.Parse(CbxSize.Text) * 30), 50+ (int.Parse(CbxSize.Text) * 30));
            gbxTablero.Location = new Point(20, 20);
            gbxTablero.Text = "Tablero";
            this.Controls.Add(gbxTablero);
            Random r = new Random();
            for (int i=0;i<pos.Length;i++) //Asignar lugar a las bombas
            {
                ii:
                int x = r.Next(0, int.Parse(CbxSize.Text)*int.Parse(CbxSize.Text));
                if (pos.Contains(x))
                {
                    //Console.WriteLine("Restart");
                    goto ii;
                }
                else
                {
                    pos[i] = x;
                }
                //Console.WriteLine(pos[i]);
            }
            GenerarVecinos();

            //int[] Vecino = new int[0];
            //int[] values = new[] { 1, 2, 3, 4, 5, 4, 4, 3 };
            //Array.Resize(ref Vecino, Vecino.Length + 1);

            /*
            foreach (int a in Vecinos)
            {
                if (a < 100)
                {
                    Array.Resize(ref Vecino, Vecino.Length + 1);
                    Vecino[Vecino.Length - 1] = a;
                    //Console.WriteLine(a);
                }
            }*/


            /*foreach(int i in Vecino)
            {
                Console.WriteLine(Vecino[i]);
            }*/
            var VEC = Vecinotl.GroupBy(v => v);
            //var groups = values.GroupBy(v => v);
            //foreach (var group in groups)
            //Console.WriteLine("Value {0} has {1} items", group.Key, group.Count());
            Console.WriteLine("Vecinos de verdad");

            for (int Columnas=0;Columnas< int.Parse(CbxSize.Text); Columnas++) //Generar Tiles
            {
                for(int Renglon=0;Renglon< int.Parse(CbxSize.Text); Renglon++)
                {
                    Point Loc = new Point(30 + (Columnas * 30), 30 + (Renglon * 30));
                    Button Tile = new Button();
                    gbxTablero.Controls.Add(Tile);
                    Tile.Size = new Size(30, 30);
                    Tile.Location = Loc;
                    Tile.BackColor = Color.LightGray;
                    Tile.ForeColor = Color.LightGray;
                    Tile.Text = "0";
                    Tile.Click += new EventHandler(this.TileClick);
                    Tile.MouseDown += new MouseEventHandler(this.FlagClick);
                    Tile.TabIndex = ((Columnas * int.Parse(CbxSize.Text)) + Renglon) + 2;
                    Tile.TabStop = true;
                    if (pos.Contains((Columnas * int.Parse(CbxSize.Text)) + Renglon)) //Asignar estado de bombas
                    {
                        int u = 0;
                        uu:
                        if(Bombas[u]==null)
                        {
                            Bombas[u] = Tile;
                        }
                        else
                        {
                            u++;
                            goto uu;
                        }
                        Tile.Text = "B";
                        //Tile.BackColor = Color.Red;
                    }//Bombas}
                    foreach(var grupo in VEC)
                    {
                        //Console.WriteLine(grupo.Key + "-" + grupo.Count());
                        if (((Columnas * int.Parse(CbxSize.Text)) + Renglon)==grupo.Key && Tile.Text!="B")
                        {
                            Tile.Text = grupo.Count().ToString();
                            break;
                        }
                    }

                }
            }
            /*foreach (var grupo in VEC)
            {
                Console.WriteLine(grupo.Key + "-" + grupo.Count());
                if (((Columnas * 10) + Renglon) == grupo.Key && Tile.Text != "B")
                {
                    Tile.Text = grupo.Count().ToString();
                    break;
                }
            }*/

        }
        public void GenerarVecinos()
        {
            Console.WriteLine("Bombas");
            for (int i = 0; i < pos.Length; i++)
            {
                if (pos[i] == 0)//A 3 vecinos
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 3);
                    Vecinotl[Vecinotl.Length - 3] = pos[i] + 1;
                    Vecinotl[Vecinotl.Length - 2] = pos[i] + int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 1] = pos[i] + int.Parse(CbxSize.Text) +1;
                    Console.WriteLine("A" + pos[i]);
                    //Vecinos[i, 0] = pos[i] + 1;
                    //Vecinos[i, 1] = pos[i] + 10;
                    //Vecinos[i, 2] = pos[i] + 11;
                }
                else if (pos[i] == int.Parse(CbxSize.Text)-1)//C 3 vecinos 9
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 3);
                    Vecinotl[Vecinotl.Length - 3] = pos[i] - 1;
                    Vecinotl[Vecinotl.Length - 2] = pos[i] + int.Parse(CbxSize.Text) -1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] + int.Parse(CbxSize.Text);
                    Console.WriteLine("C" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 1;
                    //Vecinos[i, 1] = pos[i] + 9;
                    //Vecinos[i, 2] = pos[i] + 10;
                }
                else if (pos[i] == Math.Pow(int.Parse(CbxSize.Text), 2) - int.Parse(CbxSize.Text))//G 3 vecinos 90
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 3);
                    Vecinotl[Vecinotl.Length - 3] = pos[i] - int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 2] = pos[i] - int.Parse(CbxSize.Text) +1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] + 1;
                    Console.WriteLine("G" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 10;
                    //Vecinos[i, 1] = pos[i] - 9;
                    //Vecinos[i, 2] = pos[i] + 1;
                }
                else if (pos[i] == Math.Pow(int.Parse(CbxSize.Text), 2)-1)//I 3 vecinos 99
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 3);
                    Vecinotl[Vecinotl.Length - 3] = pos[i] - 1;
                    Vecinotl[Vecinotl.Length - 2] = pos[i] - int.Parse(CbxSize.Text)-1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] - int.Parse(CbxSize.Text);
                    Console.WriteLine("I" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 1;
                    //Vecinos[i, 1] = pos[i] - 11;
                    //Vecinos[i, 2] = pos[i] - 10;
                }
                else if (pos[i] > 0 && pos[i] < int.Parse(CbxSize.Text)-1)//B 5 vecinos <9
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 5);
                    Vecinotl[Vecinotl.Length - 5] = pos[i] - 1;
                    Vecinotl[Vecinotl.Length - 4] = pos[i] + int.Parse(CbxSize.Text)-1;
                    Vecinotl[Vecinotl.Length - 3] = pos[i] + int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 2] = pos[i] + int.Parse(CbxSize.Text)+1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] + 1;
                    Console.WriteLine("B" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 1;
                    //Vecinos[i, 1] = pos[i] + 9;
                    //Vecinos[i, 2] = pos[i] + 10;
                    //Vecinos[i, 3] = pos[i] + 11;
                    //Vecinos[i, 4] = pos[i] + 1;
                }
                else if (pos[i] > Math.Pow(int.Parse(CbxSize.Text), 2) - int.Parse(CbxSize.Text) && 
                    pos[i] < Math.Pow(int.Parse(CbxSize.Text), 2) - 1)//H 5 vecinos 90 < i < 99
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 5);
                    Vecinotl[Vecinotl.Length - 5] = pos[i] - 1;
                    Vecinotl[Vecinotl.Length - 4] = pos[i] - int.Parse(CbxSize.Text)-1;
                    Vecinotl[Vecinotl.Length - 3] = pos[i] - int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 2] = pos[i] - int.Parse(CbxSize.Text)+1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] + 1;
                    Console.WriteLine("H" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 1;
                    //Vecinos[i, 1] = pos[i] - 11;
                    //Vecinos[i, 2] = pos[i] - 10;
                    //Vecinos[i, 3] = pos[i] - 9;
                    //Vecinos[i, 4] = pos[i] + 1;
                }
                else if (pos[i] % int.Parse(CbxSize.Text) == 0 && 
                    pos[i] != Math.Pow(int.Parse(CbxSize.Text), 2) - int.Parse(CbxSize.Text))//D 5 vecinos %10 =0 y !=90
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 5);
                    Vecinotl[Vecinotl.Length - 5] = pos[i] - int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 4] = pos[i] - int.Parse(CbxSize.Text)+1;
                    Vecinotl[Vecinotl.Length - 3] = pos[i] + 1;
                    Vecinotl[Vecinotl.Length - 2] = pos[i] + int.Parse(CbxSize.Text)+1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] + int.Parse(CbxSize.Text);
                    Console.WriteLine("D" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 10;
                    //Vecinos[i, 1] = pos[i] - 9;
                    //Vecinos[i, 2] = pos[i] + 1;
                    //Vecinos[i, 3] = pos[i] + 11;
                    //Vecinos[i, 4] = pos[i] + 10;
                }
                else if ((pos[i]- int.Parse(CbxSize.Text) + 1) % int.Parse(CbxSize.Text) == 0 && 
                    pos[i] != Math.Pow(int.Parse(CbxSize.Text), 2) - 1)//F 5 vecinos pos[i]-9) % 10 == 0 && pos[i] != 99
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 5);
                    Vecinotl[Vecinotl.Length - 5] = pos[i] - int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 4] = pos[i] - int.Parse(CbxSize.Text)-1;
                    Vecinotl[Vecinotl.Length - 3] = pos[i] - 1;
                    Vecinotl[Vecinotl.Length - 2] = pos[i] + int.Parse(CbxSize.Text)-1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] + int.Parse(CbxSize.Text);
                    Console.WriteLine("F" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 10;
                    //Vecinos[i, 1] = pos[i] - 11;
                    //Vecinos[i, 2] = pos[i] - 1;
                    //Vecinos[i, 3] = pos[i] + 9;
                    //Vecinos[i, 4] = pos[i] + 10;
                }
                else // 8 vecinos
                {
                    Array.Resize(ref Vecinotl, Vecinotl.Length + 8);
                    Vecinotl[Vecinotl.Length - 8] = pos[i] - int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 7] = pos[i] - int.Parse(CbxSize.Text)-1;
                    Vecinotl[Vecinotl.Length - 6] = pos[i] - 1;
                    Vecinotl[Vecinotl.Length - 5] = pos[i] + int.Parse(CbxSize.Text)-1;
                    Vecinotl[Vecinotl.Length - 4] = pos[i] + int.Parse(CbxSize.Text);
                    Vecinotl[Vecinotl.Length - 3] = pos[i] + int.Parse(CbxSize.Text)+1;
                    Vecinotl[Vecinotl.Length - 2] = pos[i] + 1;
                    Vecinotl[Vecinotl.Length - 1] = pos[i] - int.Parse(CbxSize.Text)+1;
                    Console.WriteLine("E" + pos[i]);
                    //Vecinos[i, 0] = pos[i] - 10;
                    //Vecinos[i, 1] = pos[i] - 11;
                    //Vecinos[i, 2] = pos[i] - 1;
                    //Vecinos[i, 3] = pos[i] + 9;
                    //Vecinos[i, 4] = pos[i] + 10;
                    //Vecinos[i, 5] = pos[i] + 11;
                    //Vecinos[i, 6] = pos[i] + 1;
                    //Vecinos[i, 7] = pos[i] - 9;

                }
            }
        }
        public void TileClick(object sender, EventArgs e)
        {
            
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Orange)
            {
                btn.Enabled = false;
                if (btn.Text == "B")
                {
                    for (int i = 0; i < pos.Length; i++)
                    {
                        Bombas[i].BackColor = Color.Red;
                        Bombas[i].Text = "";

                    }
                    gbxTablero.Enabled = false;
                    t.Enabled = false;
                    lblTimer.ForeColor = Color.Red;

                    /*
                    foreach (Button btnn in this.Controls)
                    {

                        if (btnn.Name != "btnReiniciar")
                        {
                            btnn.Enabled = false;
                        }
                    }*/
                }
                else if (btn.Text == "0")
                {
                    btn.BackColor = Color.Green;
                    btn.Text = "";

                }
            }
        }
        public void FlagClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                int k = 0;
                Button btn = (Button)sender;
                if (btn.BackColor == Color.LightGray)
                {
                    btn.BackColor = Color.Orange;
                    btn.ForeColor = Color.Orange;
                    Flags++;
                    Check(k);
                    /*foreach(Button bombs in Bombas)
                    {
                        if(bombs.BackColor==Color.Orange)
                        {
                            k++;
                        }
                    }
                    if (k == Bombas.Length && Flags == k)
                    {
                        gbxTablero.Enabled = false;
                        t.Enabled = false;
                        lblTimer.ForeColor = Color.Green;
                    }*/
                }
                else
                {
                    Flags--;
                    btn.BackColor = Color.LightGray;
                    btn.ForeColor = Color.LightGray;
                    Check(k);
                }
            }
        }
        public void Check(int k)
        {
            foreach (Button bombs in Bombas)
            {
                if (bombs.BackColor == Color.Orange)
                {
                    k++;
                }
            }
            if (k == Bombas.Length && Flags == k)
            {
                gbxTablero.Enabled = false;
                t.Enabled = false;
                lblTimer.ForeColor = Color.Green;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }


    }
}
