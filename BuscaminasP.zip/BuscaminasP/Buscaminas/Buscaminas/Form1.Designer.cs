﻿namespace Buscaminas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnReiniciar = new System.Windows.Forms.Button();
            this.lblTimer = new System.Windows.Forms.Label();
            this.BtnGenerar = new System.Windows.Forms.Button();
            this.BtnSalir = new System.Windows.Forms.Button();
            this.CbxSize = new System.Windows.Forms.ComboBox();
            this.CbxMinas = new System.Windows.Forms.ComboBox();
            this.LblMinas = new System.Windows.Forms.Label();
            this.LblSize = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnReiniciar
            // 
            this.BtnReiniciar.Location = new System.Drawing.Point(1150, 446);
            this.BtnReiniciar.Name = "BtnReiniciar";
            this.BtnReiniciar.Size = new System.Drawing.Size(167, 72);
            this.BtnReiniciar.TabIndex = 0;
            this.BtnReiniciar.Text = "Reiniciar";
            this.BtnReiniciar.UseVisualStyleBackColor = true;
            this.BtnReiniciar.Click += new System.EventHandler(this.btnReiniciar_Click);
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.Location = new System.Drawing.Point(1111, 83);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(179, 69);
            this.lblTimer.TabIndex = 1;
            this.lblTimer.Text = "00:00";
            // 
            // BtnGenerar
            // 
            this.BtnGenerar.Location = new System.Drawing.Point(1150, 368);
            this.BtnGenerar.Name = "BtnGenerar";
            this.BtnGenerar.Size = new System.Drawing.Size(167, 72);
            this.BtnGenerar.TabIndex = 2;
            this.BtnGenerar.Text = "Iniciar";
            this.BtnGenerar.UseVisualStyleBackColor = true;
            this.BtnGenerar.Click += new System.EventHandler(this.BtnGenerar_Click);
            // 
            // BtnSalir
            // 
            this.BtnSalir.Location = new System.Drawing.Point(1150, 524);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(167, 72);
            this.BtnSalir.TabIndex = 3;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // CbxSize
            // 
            this.CbxSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxSize.FormattingEnabled = true;
            this.CbxSize.Items.AddRange(new object[] {
            "10",
            "16",
            "20"});
            this.CbxSize.Location = new System.Drawing.Point(1258, 292);
            this.CbxSize.Name = "CbxSize";
            this.CbxSize.Size = new System.Drawing.Size(59, 24);
            this.CbxSize.TabIndex = 4;
            // 
            // CbxMinas
            // 
            this.CbxMinas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxMinas.FormattingEnabled = true;
            this.CbxMinas.Items.AddRange(new object[] {
            "15",
            "30",
            "45"});
            this.CbxMinas.Location = new System.Drawing.Point(1258, 191);
            this.CbxMinas.Name = "CbxMinas";
            this.CbxMinas.Size = new System.Drawing.Size(59, 24);
            this.CbxMinas.TabIndex = 5;
            // 
            // LblMinas
            // 
            this.LblMinas.AutoSize = true;
            this.LblMinas.Location = new System.Drawing.Point(1147, 194);
            this.LblMinas.Name = "LblMinas";
            this.LblMinas.Size = new System.Drawing.Size(45, 17);
            this.LblMinas.TabIndex = 6;
            this.LblMinas.Text = "Minas";
            // 
            // LblSize
            // 
            this.LblSize.AutoSize = true;
            this.LblSize.Location = new System.Drawing.Point(1147, 295);
            this.LblSize.Name = "LblSize";
            this.LblSize.Size = new System.Drawing.Size(60, 17);
            this.LblSize.TabIndex = 7;
            this.LblSize.Text = "Tamaño";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1332, 1055);
            this.Controls.Add(this.LblSize);
            this.Controls.Add(this.LblMinas);
            this.Controls.Add(this.CbxMinas);
            this.Controls.Add(this.CbxSize);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnGenerar);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.BtnReiniciar);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BuscaMinas";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnReiniciar;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button BtnGenerar;
        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.ComboBox CbxSize;
        private System.Windows.Forms.ComboBox CbxMinas;
        private System.Windows.Forms.Label LblMinas;
        private System.Windows.Forms.Label LblSize;
    }
}

