﻿namespace BattleShip
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PbxTablero = new System.Windows.Forms.PictureBox();
            this.PbxTableroPlayer = new System.Windows.Forms.PictureBox();
            this.LblOrientación = new System.Windows.Forms.Label();
            this.BtnReiniciar = new System.Windows.Forms.Button();
            this.CbxOrient = new System.Windows.Forms.ComboBox();
            this.CbxDificultad = new System.Windows.Forms.ComboBox();
            this.LblDificultad = new System.Windows.Forms.Label();
            this.GbxSettings = new System.Windows.Forms.GroupBox();
            this.BtnIniciar = new System.Windows.Forms.Button();
            this.LblTirosIA = new System.Windows.Forms.Label();
            this.LblTirosPlayer = new System.Windows.Forms.Label();
            this.BtnRendirse = new System.Windows.Forms.Button();
            this.GbxIngame = new System.Windows.Forms.GroupBox();
            this.lblPlayerDisplay = new System.Windows.Forms.Label();
            this.LblIADisplay = new System.Windows.Forms.Label();
            this.LblDif = new System.Windows.Forms.Label();
            this.LblMiss = new System.Windows.Forms.Label();
            this.LblMissPlayer = new System.Windows.Forms.Label();
            this.LblMissIA = new System.Windows.Forms.Label();
            this.LblImpactos = new System.Windows.Forms.Label();
            this.LblImpPlayer = new System.Windows.Forms.Label();
            this.LblImpIA = new System.Windows.Forms.Label();
            this.LblTiros = new System.Windows.Forms.Label();
            this.PbxShip5 = new System.Windows.Forms.PictureBox();
            this.PbxShip4 = new System.Windows.Forms.PictureBox();
            this.PbxShip3 = new System.Windows.Forms.PictureBox();
            this.PbxShip2 = new System.Windows.Forms.PictureBox();
            this.PbxShip1 = new System.Windows.Forms.PictureBox();
            this.GbxShips = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.PbxTablero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxTableroPlayer)).BeginInit();
            this.GbxSettings.SuspendLayout();
            this.GbxIngame.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip1)).BeginInit();
            this.GbxShips.SuspendLayout();
            this.SuspendLayout();
            // 
            // PbxTablero
            // 
            this.PbxTablero.BackColor = System.Drawing.Color.RoyalBlue;
            this.PbxTablero.Enabled = false;
            this.PbxTablero.Location = new System.Drawing.Point(26, 30);
            this.PbxTablero.Name = "PbxTablero";
            this.PbxTablero.Size = new System.Drawing.Size(600, 600);
            this.PbxTablero.TabIndex = 0;
            this.PbxTablero.TabStop = false;
            this.PbxTablero.Click += new System.EventHandler(this.PbxTablero_Click);
            this.PbxTablero.Paint += new System.Windows.Forms.PaintEventHandler(this.PbxTablero_Paint);
            this.PbxTablero.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PbxTablero_MouseMove);
            // 
            // PbxTableroPlayer
            // 
            this.PbxTableroPlayer.BackColor = System.Drawing.Color.RoyalBlue;
            this.PbxTableroPlayer.Location = new System.Drawing.Point(856, 30);
            this.PbxTableroPlayer.Name = "PbxTableroPlayer";
            this.PbxTableroPlayer.Size = new System.Drawing.Size(600, 600);
            this.PbxTableroPlayer.TabIndex = 4;
            this.PbxTableroPlayer.TabStop = false;
            this.PbxTableroPlayer.Click += new System.EventHandler(this.PbxTableroPlayer_Click);
            this.PbxTableroPlayer.Paint += new System.Windows.Forms.PaintEventHandler(this.PbxTableroPlayer_Paint);
            this.PbxTableroPlayer.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PbxTableroPlayer_MouseMove);
            // 
            // LblOrientación
            // 
            this.LblOrientación.AutoSize = true;
            this.LblOrientación.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblOrientación.Location = new System.Drawing.Point(32, 93);
            this.LblOrientación.Name = "LblOrientación";
            this.LblOrientación.Size = new System.Drawing.Size(155, 28);
            this.LblOrientación.TabIndex = 5;
            this.LblOrientación.Text = "Orientación";
            // 
            // BtnReiniciar
            // 
            this.BtnReiniciar.Font = new System.Drawing.Font("Consolas", 15.2F);
            this.BtnReiniciar.Location = new System.Drawing.Point(4, 38);
            this.BtnReiniciar.Name = "BtnReiniciar";
            this.BtnReiniciar.Size = new System.Drawing.Size(208, 41);
            this.BtnReiniciar.TabIndex = 6;
            this.BtnReiniciar.Text = "Reiniciar";
            this.BtnReiniciar.UseVisualStyleBackColor = true;
            this.BtnReiniciar.Click += new System.EventHandler(this.BtnReiniciar_Click);
            // 
            // CbxOrient
            // 
            this.CbxOrient.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxOrient.Items.AddRange(new object[] {
            "Horizontal",
            "Vertical"});
            this.CbxOrient.Location = new System.Drawing.Point(3, 124);
            this.CbxOrient.Name = "CbxOrient";
            this.CbxOrient.Size = new System.Drawing.Size(206, 40);
            this.CbxOrient.TabIndex = 7;
            this.CbxOrient.SelectedIndexChanged += new System.EventHandler(this.CbxOrient_SelectedIndexChanged);
            // 
            // CbxDificultad
            // 
            this.CbxDificultad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxDificultad.Items.AddRange(new object[] {
            "Fácil",
            "Normal",
            "Difícil"});
            this.CbxDificultad.Location = new System.Drawing.Point(3, 209);
            this.CbxDificultad.Name = "CbxDificultad";
            this.CbxDificultad.Size = new System.Drawing.Size(206, 40);
            this.CbxDificultad.TabIndex = 9;
            // 
            // LblDificultad
            // 
            this.LblDificultad.AutoSize = true;
            this.LblDificultad.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblDificultad.Location = new System.Drawing.Point(32, 178);
            this.LblDificultad.Name = "LblDificultad";
            this.LblDificultad.Size = new System.Drawing.Size(142, 28);
            this.LblDificultad.TabIndex = 8;
            this.LblDificultad.Text = "Dificultad";
            // 
            // GbxSettings
            // 
            this.GbxSettings.Controls.Add(this.BtnIniciar);
            this.GbxSettings.Controls.Add(this.BtnReiniciar);
            this.GbxSettings.Controls.Add(this.CbxDificultad);
            this.GbxSettings.Controls.Add(this.LblOrientación);
            this.GbxSettings.Controls.Add(this.LblDificultad);
            this.GbxSettings.Controls.Add(this.CbxOrient);
            this.GbxSettings.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GbxSettings.Location = new System.Drawing.Point(632, 30);
            this.GbxSettings.Name = "GbxSettings";
            this.GbxSettings.Size = new System.Drawing.Size(218, 324);
            this.GbxSettings.TabIndex = 10;
            this.GbxSettings.TabStop = false;
            this.GbxSettings.Text = "Opciones";
            // 
            // BtnIniciar
            // 
            this.BtnIniciar.Enabled = false;
            this.BtnIniciar.Font = new System.Drawing.Font("Consolas", 15.2F);
            this.BtnIniciar.Location = new System.Drawing.Point(6, 268);
            this.BtnIniciar.Name = "BtnIniciar";
            this.BtnIniciar.Size = new System.Drawing.Size(206, 41);
            this.BtnIniciar.TabIndex = 10;
            this.BtnIniciar.Text = "Iniciar";
            this.BtnIniciar.UseVisualStyleBackColor = true;
            this.BtnIniciar.Click += new System.EventHandler(this.BtnIniciar_Click);
            // 
            // LblTirosIA
            // 
            this.LblTirosIA.AutoSize = true;
            this.LblTirosIA.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblTirosIA.Location = new System.Drawing.Point(7, 89);
            this.LblTirosIA.Name = "LblTirosIA";
            this.LblTirosIA.Size = new System.Drawing.Size(142, 28);
            this.LblTirosIA.TabIndex = 8;
            this.LblTirosIA.Text = "Máquina: 0";
            // 
            // LblTirosPlayer
            // 
            this.LblTirosPlayer.AutoSize = true;
            this.LblTirosPlayer.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblTirosPlayer.Location = new System.Drawing.Point(6, 61);
            this.LblTirosPlayer.Name = "LblTirosPlayer";
            this.LblTirosPlayer.Size = new System.Drawing.Size(142, 28);
            this.LblTirosPlayer.TabIndex = 5;
            this.LblTirosPlayer.Text = "Jugador: 0";
            // 
            // BtnRendirse
            // 
            this.BtnRendirse.BackColor = System.Drawing.Color.SeaShell;
            this.BtnRendirse.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnRendirse.Font = new System.Drawing.Font("Consolas", 15.2F);
            this.BtnRendirse.ForeColor = System.Drawing.Color.Navy;
            this.BtnRendirse.Location = new System.Drawing.Point(6, 382);
            this.BtnRendirse.Name = "BtnRendirse";
            this.BtnRendirse.Size = new System.Drawing.Size(206, 41);
            this.BtnRendirse.TabIndex = 10;
            this.BtnRendirse.Text = "Rendirse";
            this.BtnRendirse.UseVisualStyleBackColor = false;
            this.BtnRendirse.Click += new System.EventHandler(this.BtnRendirse_Click);
            // 
            // GbxIngame
            // 
            this.GbxIngame.Controls.Add(this.lblPlayerDisplay);
            this.GbxIngame.Controls.Add(this.LblIADisplay);
            this.GbxIngame.Controls.Add(this.LblDif);
            this.GbxIngame.Controls.Add(this.LblMiss);
            this.GbxIngame.Controls.Add(this.LblMissPlayer);
            this.GbxIngame.Controls.Add(this.LblMissIA);
            this.GbxIngame.Controls.Add(this.LblImpactos);
            this.GbxIngame.Controls.Add(this.LblImpPlayer);
            this.GbxIngame.Controls.Add(this.LblImpIA);
            this.GbxIngame.Controls.Add(this.LblTiros);
            this.GbxIngame.Controls.Add(this.BtnRendirse);
            this.GbxIngame.Controls.Add(this.LblTirosPlayer);
            this.GbxIngame.Controls.Add(this.LblTirosIA);
            this.GbxIngame.Font = new System.Drawing.Font("Consolas", 15F);
            this.GbxIngame.Location = new System.Drawing.Point(632, 30);
            this.GbxIngame.Name = "GbxIngame";
            this.GbxIngame.Size = new System.Drawing.Size(218, 431);
            this.GbxIngame.TabIndex = 11;
            this.GbxIngame.TabStop = false;
            this.GbxIngame.Text = "Estadísticas";
            this.GbxIngame.Visible = false;
            // 
            // lblPlayerDisplay
            // 
            this.lblPlayerDisplay.AutoSize = true;
            this.lblPlayerDisplay.Font = new System.Drawing.Font("Consolas", 14F);
            this.lblPlayerDisplay.Location = new System.Drawing.Point(6, 323);
            this.lblPlayerDisplay.Name = "lblPlayerDisplay";
            this.lblPlayerDisplay.Size = new System.Drawing.Size(129, 28);
            this.lblPlayerDisplay.TabIndex = 22;
            this.lblPlayerDisplay.Tag = "";
            this.lblPlayerDisplay.Text = "Jugador: ";
            // 
            // LblIADisplay
            // 
            this.LblIADisplay.AutoSize = true;
            this.LblIADisplay.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblIADisplay.Location = new System.Drawing.Point(6, 351);
            this.LblIADisplay.Name = "LblIADisplay";
            this.LblIADisplay.Size = new System.Drawing.Size(129, 28);
            this.LblIADisplay.TabIndex = 21;
            this.LblIADisplay.Text = "Máquina: ";
            // 
            // LblDif
            // 
            this.LblDif.AutoSize = true;
            this.LblDif.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblDif.Location = new System.Drawing.Point(5, 295);
            this.LblDif.Name = "LblDif";
            this.LblDif.Size = new System.Drawing.Size(207, 28);
            this.LblDif.TabIndex = 20;
            this.LblDif.Text = "----Difícil----";
            // 
            // LblMiss
            // 
            this.LblMiss.AutoSize = true;
            this.LblMiss.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblMiss.Location = new System.Drawing.Point(5, 201);
            this.LblMiss.Name = "LblMiss";
            this.LblMiss.Size = new System.Drawing.Size(220, 28);
            this.LblMiss.TabIndex = 17;
            this.LblMiss.Text = "------Miss------";
            // 
            // LblMissPlayer
            // 
            this.LblMissPlayer.AutoSize = true;
            this.LblMissPlayer.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblMissPlayer.Location = new System.Drawing.Point(6, 229);
            this.LblMissPlayer.Name = "LblMissPlayer";
            this.LblMissPlayer.Size = new System.Drawing.Size(142, 28);
            this.LblMissPlayer.TabIndex = 15;
            this.LblMissPlayer.Text = "Jugador: 0";
            // 
            // LblMissIA
            // 
            this.LblMissIA.AutoSize = true;
            this.LblMissIA.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblMissIA.Location = new System.Drawing.Point(6, 257);
            this.LblMissIA.Name = "LblMissIA";
            this.LblMissIA.Size = new System.Drawing.Size(142, 28);
            this.LblMissIA.TabIndex = 16;
            this.LblMissIA.Text = "Máquina: 0";
            // 
            // LblImpactos
            // 
            this.LblImpactos.AutoSize = true;
            this.LblImpactos.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblImpactos.Location = new System.Drawing.Point(6, 117);
            this.LblImpactos.Name = "LblImpactos";
            this.LblImpactos.Size = new System.Drawing.Size(220, 28);
            this.LblImpactos.TabIndex = 14;
            this.LblImpactos.Text = "----Impactos----";
            // 
            // LblImpPlayer
            // 
            this.LblImpPlayer.AutoSize = true;
            this.LblImpPlayer.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblImpPlayer.Location = new System.Drawing.Point(6, 145);
            this.LblImpPlayer.Name = "LblImpPlayer";
            this.LblImpPlayer.Size = new System.Drawing.Size(142, 28);
            this.LblImpPlayer.TabIndex = 12;
            this.LblImpPlayer.Text = "Jugador: 0";
            // 
            // LblImpIA
            // 
            this.LblImpIA.AutoSize = true;
            this.LblImpIA.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblImpIA.Location = new System.Drawing.Point(6, 173);
            this.LblImpIA.Name = "LblImpIA";
            this.LblImpIA.Size = new System.Drawing.Size(142, 28);
            this.LblImpIA.TabIndex = 13;
            this.LblImpIA.Text = "Máquina: 0";
            // 
            // LblTiros
            // 
            this.LblTiros.AutoSize = true;
            this.LblTiros.Font = new System.Drawing.Font("Consolas", 14F);
            this.LblTiros.Location = new System.Drawing.Point(5, 33);
            this.LblTiros.Name = "LblTiros";
            this.LblTiros.Size = new System.Drawing.Size(207, 28);
            this.LblTiros.TabIndex = 11;
            this.LblTiros.Text = "-----Tiros-----";
            // 
            // PbxShip5
            // 
            this.PbxShip5.BackColor = System.Drawing.Color.Gold;
            this.PbxShip5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbxShip5.Location = new System.Drawing.Point(6, 21);
            this.PbxShip5.Name = "PbxShip5";
            this.PbxShip5.Size = new System.Drawing.Size(150, 30);
            this.PbxShip5.TabIndex = 12;
            this.PbxShip5.TabStop = false;
            // 
            // PbxShip4
            // 
            this.PbxShip4.BackColor = System.Drawing.Color.Gold;
            this.PbxShip4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbxShip4.Location = new System.Drawing.Point(6, 67);
            this.PbxShip4.Name = "PbxShip4";
            this.PbxShip4.Size = new System.Drawing.Size(120, 30);
            this.PbxShip4.TabIndex = 13;
            this.PbxShip4.TabStop = false;
            // 
            // PbxShip3
            // 
            this.PbxShip3.BackColor = System.Drawing.Color.Gold;
            this.PbxShip3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbxShip3.Location = new System.Drawing.Point(212, 21);
            this.PbxShip3.Name = "PbxShip3";
            this.PbxShip3.Size = new System.Drawing.Size(90, 30);
            this.PbxShip3.TabIndex = 14;
            this.PbxShip3.TabStop = false;
            // 
            // PbxShip2
            // 
            this.PbxShip2.BackColor = System.Drawing.Color.Gold;
            this.PbxShip2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbxShip2.Location = new System.Drawing.Point(212, 67);
            this.PbxShip2.Name = "PbxShip2";
            this.PbxShip2.Size = new System.Drawing.Size(90, 30);
            this.PbxShip2.TabIndex = 15;
            this.PbxShip2.TabStop = false;
            // 
            // PbxShip1
            // 
            this.PbxShip1.BackColor = System.Drawing.Color.Gold;
            this.PbxShip1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbxShip1.Location = new System.Drawing.Point(366, 21);
            this.PbxShip1.Name = "PbxShip1";
            this.PbxShip1.Size = new System.Drawing.Size(60, 30);
            this.PbxShip1.TabIndex = 16;
            this.PbxShip1.TabStop = false;
            // 
            // GbxShips
            // 
            this.GbxShips.Controls.Add(this.PbxShip5);
            this.GbxShips.Controls.Add(this.PbxShip1);
            this.GbxShips.Controls.Add(this.PbxShip4);
            this.GbxShips.Controls.Add(this.PbxShip2);
            this.GbxShips.Controls.Add(this.PbxShip3);
            this.GbxShips.Location = new System.Drawing.Point(101, 636);
            this.GbxShips.Name = "GbxShips";
            this.GbxShips.Size = new System.Drawing.Size(440, 105);
            this.GbxShips.TabIndex = 17;
            this.GbxShips.TabStop = false;
            this.GbxShips.Text = "Barcos Enemigos";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.GbxShips);
            this.Controls.Add(this.GbxIngame);
            this.Controls.Add(this.GbxSettings);
            this.Controls.Add(this.PbxTableroPlayer);
            this.Controls.Add(this.PbxTablero);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BattleShip";
            ((System.ComponentModel.ISupportInitialize)(this.PbxTablero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxTableroPlayer)).EndInit();
            this.GbxSettings.ResumeLayout(false);
            this.GbxSettings.PerformLayout();
            this.GbxIngame.ResumeLayout(false);
            this.GbxIngame.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxShip1)).EndInit();
            this.GbxShips.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PbxTablero;
        private System.Windows.Forms.PictureBox PbxTableroPlayer;
        private System.Windows.Forms.Label LblOrientación;
        private System.Windows.Forms.Button BtnReiniciar;
        private System.Windows.Forms.ComboBox CbxOrient;
        private System.Windows.Forms.ComboBox CbxDificultad;
        private System.Windows.Forms.Label LblDificultad;
        private System.Windows.Forms.GroupBox GbxSettings;
        private System.Windows.Forms.Button BtnIniciar;
        private System.Windows.Forms.Label LblTirosIA;
        private System.Windows.Forms.Label LblTirosPlayer;
        private System.Windows.Forms.Button BtnRendirse;
        private System.Windows.Forms.GroupBox GbxIngame;
        private System.Windows.Forms.Label LblTiros;
        private System.Windows.Forms.Label LblDif;
        private System.Windows.Forms.Label LblMiss;
        private System.Windows.Forms.Label LblMissPlayer;
        private System.Windows.Forms.Label LblMissIA;
        private System.Windows.Forms.Label LblImpactos;
        private System.Windows.Forms.Label LblImpPlayer;
        private System.Windows.Forms.Label LblImpIA;
        private System.Windows.Forms.Label LblIADisplay;
        private System.Windows.Forms.Label lblPlayerDisplay;
        private System.Windows.Forms.PictureBox PbxShip5;
        private System.Windows.Forms.PictureBox PbxShip4;
        private System.Windows.Forms.PictureBox PbxShip3;
        private System.Windows.Forms.PictureBox PbxShip2;
        private System.Windows.Forms.PictureBox PbxShip1;
        private System.Windows.Forms.GroupBox GbxShips;
    }
}

