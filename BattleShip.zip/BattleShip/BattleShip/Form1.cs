﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;

//TO-DO
//Revisar los HITs que de el jugador a la IA
//Crear mejor IA
namespace BattleShip
{

    public partial class Form1 : Form
    {

        public int SizeTab = 10;

        public int PlayerDisparos = 0;
        public int IADisparos = 0;

        public int PlayerHit = 0;
        public int IAHit = 0;

        public string[][] PlayerBarcoss = new string[][]
            {
            new string[] {"99","99","99","99","99"},
            new string[] {"99","99","99","99"},
            new string[] {"99","99","99"},
            new string[] {"99","99","99"},
            new string[] {"99","99"}
            };

        public string[][] IABarcoss = new string[][]
            {
            new string[] {"99","99","99","99","99"},
            new string[] {"99","99","99","99"},
            new string[] {"99","99","99"},
            new string[] {"99","99","99"},
            new string[] {"99","99"}
            };
        public string[] IABarcosClean = new string[0];

        public bool CanPlaceShip = false;

        public string[] HoverShips = new string[0];

        public string PlayerBarcoPos = "99";
        public string PlayerDisparoPos = "99";

        public string[] PlayerCoordDisparos = new string[0];
        public string[] IACoordDisparos = new string[0];
        public string[] ShipBlockade = new string[0];

        public Form1()
        {
            InitializeComponent();
            CbxOrient.SelectedIndex = 0;
            CbxDificultad.SelectedIndex = 0;
            
        }

        //Funciones Generales
        void DrawTablero(PaintEventArgs e)
        {
            //Cuadriculas
            {
                e.Graphics.FillRectangle(Brushes.SkyBlue, 0, 0, PbxTablero.Width, PbxTablero.Height / SizeTab);
                e.Graphics.FillRectangle(Brushes.SkyBlue, 0, 0, PbxTablero.Width / SizeTab, PbxTablero.Height);

                string[] Str = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "", "" };

                for (int i = 0; i <= SizeTab; i++)
                {

                    //Horizontal
                    e.Graphics.DrawLine(
                    new Pen(Color.Black, 1f),
                    new Point(0, i * PbxTablero.Height / SizeTab),
                    new Point(PbxTablero.Width, i * PbxTablero.Height / SizeTab));

                    //Vertical
                    e.Graphics.DrawLine(
                    new Pen(Color.Black, 1f),
                    new Point(i * PbxTablero.Width / SizeTab, 0),
                    new Point(i * PbxTablero.Width / SizeTab, PbxTablero.Height));

                    //Coordenadas
                    e.Graphics.DrawString(Str[i], new Font("Consolas", 16), Brushes.Black, new Point((i + 1) * PbxTablero.Width / SizeTab, 0));
                    e.Graphics.DrawString((i + 1).ToString(), new Font("Consolas", 16), Brushes.Black, new Point(0, (i + 1) * PbxTablero.Height / SizeTab));
                }

                e.Graphics.DrawLine(
                    new Pen(Color.Black, 1f),
                    new Point(PbxTablero.Width-1,0),
                    new Point(PbxTablero.Width-1, PbxTablero.Height-1));

                e.Graphics.DrawLine(
                    new Pen(Color.Black, 1f),
                    new Point(0,PbxTablero.Height-1),
                    new Point(PbxTablero.Width-1, PbxTablero.Height-1));
            }
        }
        private void BtnReiniciar_Click(object sender, EventArgs e)
        {
            Reiniciar();
        }
        void Reiniciar()
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < PlayerBarcoss[i].Length; j++)
                {
                    PlayerBarcoss[i][j] = "99";
                }
            }
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < IABarcoss[i].Length; j++)
                {
                    IABarcoss[i][j] = "99";
                }
            }
            PbxTablero.Enabled = false;
            PbxTableroPlayer.Enabled = true;

            PlayerDisparos = 0;
            IADisparos = 0;

            PlayerHit = 0;
            IAHit = 0;
            
            PlayerDisparoPos = "99";
            Array.Resize(ref PlayerCoordDisparos, 0);
            Array.Resize(ref IACoordDisparos, 0);
            Array.Resize(ref HoverShips, 0);
            Array.Resize(ref ShipBlockade, 0);
            Array.Resize(ref IABarcosClean, 0);

            LblTirosPlayer.Text = "Jugador: 0";
            LblTirosIA.Text = "Máquina: 0";
            LblImpPlayer.Text = "Jugador: 0";
            LblImpIA.Text = "Máquina: 0";
            LblMissPlayer.Text = "Jugador: 0";
            LblMissIA.Text = "Máquina: 0";
            PbxTablero.Refresh();
            PbxTableroPlayer.Refresh();
           


        }
        private void BtnIniciar_Click(object sender, EventArgs e)
        {
            PbxTablero.Enabled = true;
            PbxTableroPlayer.Enabled = false;
            PlayerBarcoPos = "99";
            switch (CbxDificultad.SelectedIndex)
            {
                case 0:
                    {
                        LblDif.Text = "-----Fácil-----";
                        break;
                    }
                case 1:
                    {
                        LblDif.Text = "-----Normal-----";
                        break;
                    }
                case 2:
                    {
                        LblDif.Text = "-----Difícil-----";
                        break;
                    }
            }

            GbxSettings.Enabled = false;
            GbxSettings.Visible = false;
            GbxIngame.Enabled = true;
            GbxIngame.Visible = true;


            IABarcos();
            PbxTablero.Refresh();
            PbxTableroPlayer.Refresh();
        }
        private void BtnRendirse_Click(object sender, EventArgs e)
        {
            Reiniciar();
            GbxSettings.Visible = true;
            GbxSettings.Enabled = true;
            GbxIngame.Visible = false;
            GbxIngame.Enabled = false;
            BtnIniciar.Enabled = false;
            BtnRendirse.ForeColor = Color.Navy;
            BtnRendirse.BackColor = Color.SeaShell;
            BtnRendirse.Text = "Rendirse";
            PbxShip5.BackColor = Color.Gold;
            PbxShip4.BackColor = Color.Gold;
            PbxShip3.BackColor = Color.Gold;
            PbxShip2.BackColor = Color.Gold;
            PbxShip1.BackColor = Color.Gold;
        }
        private void CbxOrient_SelectedIndexChanged(object sender, EventArgs e)
        {
            CheckShips(HoverShips);
            PbxTableroPlayer.Refresh();
            BlockShips();
        }


        //Funciones tablero de IA
        private void PbxTablero_Paint(object sender, PaintEventArgs e)
        {
            DrawBarcosIa(e);
            DrawDisparos(e);
            DrawDisparoPos(e);

            DrawTablero(e);

        }
        private void PbxTablero_MouseMove(object sender, MouseEventArgs e)
        {
            Point xy = this.PointToClient(new Point(MousePosition.X, MousePosition.Y));
            int X = xy.X - PbxTablero.Location.X - (PbxTablero.Width / SizeTab);
            int Y = xy.Y - PbxTablero.Location.Y - (PbxTablero.Height / SizeTab);

            int XX = 0;
            int YY = 0;

            //Console.WriteLine("Posición X: " + X + " MP: " + MousePosition.X);
            //Console.WriteLine("Posición Y: " + Y + " MP: " + MousePosition.Y);
            if (X > 0 && Y > 0)
            {
                for (int i = 0; i < SizeTab; i++)
                {
                    if (X < (PbxTablero.Width / SizeTab))
                    {
                        XX = i;
                        break;
                    }
                    else
                    {
                        X -= (PbxTablero.Width / SizeTab);
                    }
                }
                for (int i = 0; i < SizeTab; i++)
                {
                    if (Y < (PbxTablero.Height / SizeTab))
                    {
                        YY = i;
                        break;
                    }
                    else
                    {
                        Y -= (PbxTablero.Height / SizeTab);
                    }
                }
                if (YY == 9)
                {
                    YY = 8;
                }
                string C = XX.ToString() + YY.ToString();
                PlayerDisparoPos = C;
                PbxTablero.Refresh();
            }
        }
        private void PbxTablero_Click(object sender, EventArgs e)
        {
            if (!PlayerCoordDisparos.Contains(PlayerDisparoPos))
            {
                Array.Resize(ref PlayerCoordDisparos, PlayerCoordDisparos.Length + 1);
                PlayerCoordDisparos[PlayerDisparos] = PlayerDisparoPos;
                PlayerDisparos++;
                if (IABarcosClean.Contains(PlayerDisparoPos))
                {
                    PlayerHit++;
                    lblPlayerDisplay.Text = "Jugador: Hit!";
                    LblImpPlayer.Text = "Jugador: " +PlayerHit;
                    CheckSunken();
                }
                else
                {
                    lblPlayerDisplay.Text = "Jugador: Miss!";
                    LblMissPlayer.Text = "Jugador: " + (PlayerDisparos-PlayerHit);
                }
                //Console.WriteLine(PlayerDisparos);
                PlayerDisparoPos = "99";
                PbxTablero.Enabled = false;
                LblTirosPlayer.Text = "Jugador: " + PlayerDisparos.ToString();
                
                Thread.Sleep(800);
                switch (CbxDificultad.SelectedIndex)
                {
                    case 0:
                        {
                            IADisparaF();
                            break;
                        }
                    case 1:
                        {
                            IADisparaM();
                            break;
                        }
                    case 2:
                        {
                            IADisparaD();
                            break;
                        }
                }
                int A = 0;
                for(int i=0;i<IABarcosClean.Length;i++)
                {
                    if (PlayerCoordDisparos.Contains(IABarcosClean[i]))
                    {
                        A++;
                    }
                    else
                    {
                        A = 0;
                        break;
                    }
                }
                if(A==IABarcosClean.Length)
                {
                    Console.WriteLine("Ganaste!");
                    BtnRendirse.Text = "VICTORIA!";
                    BtnRendirse.ForeColor = Color.Teal;
                    BtnRendirse.BackColor = Color.Gold;
                    PbxTablero.Enabled = false;
                    PbxTableroPlayer.Enabled = false;
                }

            }
            else
            {
                Console.WriteLine("No puedes disparar dos veces en la misma coordenada!");
            }
            PbxTablero.Refresh();
            //Console.WriteLine(PlayerDisparoPos);
        }
        void DrawDisparoPos(PaintEventArgs e)
        {
            int Hor = int.Parse(PlayerDisparoPos.Substring(0, 1)) + 1;
            int Ver = int.Parse(PlayerDisparoPos.Substring(1, 1)) + 1;

            e.Graphics.FillEllipse(Brushes.MediumVioletRed,
                (PbxTablero.Width / SizeTab) * (Hor),
                ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                (PbxTablero.Width / SizeTab),
                (PbxTablero.Height / SizeTab));
        }
        void DrawDisparos(PaintEventArgs e)
        {
            for (int i = 0; i < PlayerDisparos; i++)
            {
                int Hor = int.Parse(PlayerCoordDisparos[i].Substring(0, 1)) + 1;
                int Ver = int.Parse(PlayerCoordDisparos[i].Substring(1, 1)) + 1;
                e.Graphics.FillEllipse(Brushes.Red,
                    (PbxTablero.Width / SizeTab) * (Hor),
                    ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                    (PbxTablero.Width / SizeTab),
                    (PbxTablero.Height / SizeTab));
            }
        }
        void DrawBarcosIa(PaintEventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < IABarcoss[i].Length; j++)
                {
                    if (int.Parse(IABarcoss[i][j]) <= 0)
                    {
                        IABarcoss[i][j] = "00";
                    }
                    else if (int.Parse(IABarcoss[i][j]) < 10)
                    {
                        IABarcoss[i][j] = "0" + (int.Parse("0" + IABarcoss[i][j])).ToString();
                    }
                    if(PlayerCoordDisparos.Contains(IABarcoss[i][j]))
                    {
                        int Hor = int.Parse(IABarcoss[i][j].Substring(0, 1)) + 1;
                        int Ver = int.Parse(IABarcoss[i][j].Substring(1, 1)) + 1;
                        e.Graphics.FillRectangle(Brushes.Gold,
                            (PbxTablero.Width / SizeTab) * (Hor),
                            ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                            (PbxTablero.Width / SizeTab),
                            (PbxTablero.Height / SizeTab));
                    }
                    if(IAHit ==17)
                    {
                                int Hor = int.Parse(IABarcoss[i][j].Substring(0, 1)) + 1;
                                int Ver = int.Parse(IABarcoss[i][j].Substring(1, 1)) + 1;
                                e.Graphics.FillRectangle(Brushes.Gold,
                                    (PbxTablero.Width / SizeTab) * (Hor),
                                    ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                                    (PbxTablero.Width / SizeTab),
                                    (PbxTablero.Height / SizeTab));
                    }
                    
                }
            }
    }
        void IADisparaF()
        {
            bool Safe;
            bool KeepShooting = true;
            while(KeepShooting)
            {
                Random R = new Random();
                string HV = R.Next(0,9).ToString() + R.Next(0,9).ToString();
                Safe = true;
                if (IADisparos % 4 == 0)
                {
                    for (int i = 0; i < PlayerBarcoss.Length; i++)
                    {
                        for (int j = 0; j < PlayerBarcoss[i].Length; j++)
                        {
                            if (!IACoordDisparos.Contains(PlayerBarcoss[i][j]))
                            {
                                Console.WriteLine("AIMED EASY");
                                HV = PlayerBarcoss[i][j];
                                KeepShooting = false;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < PlayerBarcoss.Length; i++)
                    {
                        for (int j = 0; j < PlayerBarcoss[i].Length; j++)
                        {
                            if(HV==(PlayerBarcoss[i][j]))
                            {
                                Console.WriteLine("APUNTO SOLO");
                                Safe = false;
                                break;
                            }
                        }
                    }
                }
                if (!IACoordDisparos.Contains(HV) && Safe)
                {
                    Array.Resize(ref IACoordDisparos, IACoordDisparos.Length + 1);
                    IACoordDisparos[IACoordDisparos.Length - 1] = HV;
                    IADisparos++;
                    Console.WriteLine(IACoordDisparos[IADisparos-1]);
                    Console.WriteLine(IADisparos);
                    PbxTablero.Enabled = true;
                    PbxTableroPlayer.Refresh();
                    LblTirosIA.Text = "Máquina: " + IADisparos.ToString();
                    //KeepShooting = false;
                    break;
                }
            }
        }
        void IADisparaM()
        {
            bool KeepShooting = true;
            while (KeepShooting)
            {
                Random R = new Random();
                string HV = R.Next(0, 9).ToString() + R.Next(0, 9).ToString();
                if (IADisparos % 4 == 0)
                {
                    for (int i = 0; i < PlayerBarcoss.Length; i++)
                    {
                        for (int j = 0; j < PlayerBarcoss[i].Length; j++)
                        {
                            if (!IACoordDisparos.Contains(PlayerBarcoss[i][j]))
                            {
                                Console.WriteLine("AIMED MEDIUM");
                                HV = PlayerBarcoss[i][j];
                                KeepShooting = false;
                                break;
                            }
                        }
                    }
                }

                if (!IACoordDisparos.Contains(HV))
                {
                    Array.Resize(ref IACoordDisparos, IACoordDisparos.Length + 1);
                    IACoordDisparos[IACoordDisparos.Length - 1] = HV;
                    IADisparos++;
                    Console.WriteLine(IACoordDisparos[IADisparos - 1]);
                    Console.WriteLine(IADisparos);
                    PbxTablero.Enabled = true;
                    PbxTableroPlayer.Refresh();
                    LblTirosIA.Text = "Máquina: " + IADisparos.ToString();
                    //KeepShooting = false;
                    break;
                }
            }
        }
        void IADisparaD()
        {
            bool KeepShooting = true;
            while (KeepShooting)
            {
                Random R = new Random();
                string HV = R.Next(0, 9).ToString() + R.Next(0, 9).ToString();
                if (IADisparos % 3 == 0)
                {
                    for (int i = 0; i < PlayerBarcoss.Length; i++)
                    {
                        for (int j = 0; j < PlayerBarcoss[i].Length; j++)
                        {
                            if (!IACoordDisparos.Contains(PlayerBarcoss[i][j]))
                            {
                                Console.WriteLine("AIMED HARD");
                                HV = PlayerBarcoss[i][j];
                                KeepShooting = false;
                                break;
                            }
                        }
                    }
                }
                if (!IACoordDisparos.Contains(HV))
                {
                    Array.Resize(ref IACoordDisparos, IACoordDisparos.Length + 1);
                    IACoordDisparos[IACoordDisparos.Length - 1] = HV;
                    IADisparos++;
                    Console.WriteLine(IACoordDisparos[IADisparos - 1]);
                    Console.WriteLine(IADisparos);
                    PbxTablero.Enabled = true;
                    PbxTableroPlayer.Refresh();
                    LblTirosIA.Text = "Máquina: " + IADisparos.ToString();
                    break;
                }
            }
        }
        void IACheck()
        {
            if(IAHit==17)
            {
                Console.WriteLine("Perdiste!");
                BtnRendirse.Text = "DERROTA!";
                BtnRendirse.ForeColor = Color.Gold;
                BtnRendirse.BackColor = Color.Red;
                PbxTablero.Enabled = false;
                PbxTableroPlayer.Enabled = false;
            }
        }
        void IABarcos()
        {
            Random r = new Random();
            int Hor = r.Next(1, 5);
            for(int i=0; i<Hor; i++)
            {
                switch(i)
                {
                    case 0:
                        {
                            xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[i].Length);
                            IABarcoss[i][0] = r.Next(2, 7).ToString() + r.Next(0, 9).ToString();
                            IABarcoss[i][1] = (int.Parse(IABarcoss[i][0]) + 10).ToString();
                            IABarcoss[i][2] = (int.Parse(IABarcoss[i][0]) + 20).ToString();
                            IABarcoss[i][3] = (int.Parse(IABarcoss[i][0]) - 10).ToString();
                            IABarcoss[i][4] = (int.Parse(IABarcoss[i][0]) - 20).ToString();

                            Console.WriteLine("Hor1: " + IABarcoss[i][0]);
                            for(int j=0;j<IABarcoss[i].Length;j++)
                            {
                                if (int.Parse(IABarcoss[i][j]) < 10)
                                {
                                    IABarcoss[i][j] = "0" + (int.Parse("0" + IABarcoss[i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[i].Length + j] = IABarcoss[i][j];
                                }

                            }
                            break;
                        }
                    case 1: //Barco de 4
                        {
                            xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[i].Length);
                            IABarcoss[i][0] = r.Next(1, 7).ToString() + r.Next(0, 9).ToString();
                            IABarcoss[i][1] = (int.Parse(IABarcoss[i][0]) + 10).ToString();
                            IABarcoss[i][2] = (int.Parse(IABarcoss[i][0]) + 20).ToString();
                            IABarcoss[i][3] = (int.Parse(IABarcoss[i][0]) - 10).ToString();
                            Console.WriteLine("Hor2: " + IABarcoss[i][0]);
                            for (int j = 0; j < IABarcoss[i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[i][j]) < 10)
                                {
                                    IABarcoss[i][j] = "0" + (int.Parse("0" + IABarcoss[i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[i].Length + j] = IABarcoss[i][j];
                                }

                            }
                            break;
                        }
                    case 2: //Barco de 3
                        {
                            xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[i].Length);
                            IABarcoss[i][0] = r.Next(1, 8).ToString() + r.Next(0, 9).ToString();
                            IABarcoss[i][1] = (int.Parse(IABarcoss[i][0]) + 10).ToString();
                            IABarcoss[i][2] = (int.Parse(IABarcoss[i][0]) - 10).ToString();
                            Console.WriteLine("Hor3: " + IABarcoss[i][0]);
                            for (int j = 0; j < IABarcoss[i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[i][j]) < 10)
                                {
                                    IABarcoss[i][j] = "0" + (int.Parse("0" + IABarcoss[i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[i].Length + j] = IABarcoss[i][j];
                                }

                            }
                            break;
                        }
                    case 3: //Barco de 3
                        {
                            xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[i].Length);
                            IABarcoss[i][0] = r.Next(1, 8).ToString() + r.Next(0, 9).ToString();
                            IABarcoss[i][1] = (int.Parse(IABarcoss[i][0]) + 10).ToString();
                            IABarcoss[i][2] = (int.Parse(IABarcoss[i][0]) - 10).ToString();
                            Console.WriteLine("Hor4: " + IABarcoss[i][0]);
                            for (int j = 0; j < IABarcoss[i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[i][j]) < 10)
                                {
                                    IABarcoss[i][j] = "0" + (int.Parse("0" + IABarcoss[i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[i].Length + j] = IABarcoss[i][j];
                                }

                            }
                            break;
                        }
                    case 4: //Barco de 2
                        {
                            xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[i].Length);
                            IABarcoss[i][0] = r.Next(0, 8).ToString() + r.Next(0, 9).ToString();
                            IABarcoss[i][1] = (int.Parse(IABarcoss[i][0]) + 10).ToString();
                            Console.WriteLine("Hor5: " + IABarcoss[i][0]);
                            for (int j = 0; j < IABarcoss[i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[i][j]) < 10)
                                {
                                    IABarcoss[i][j] = "0" + (int.Parse("0" + IABarcoss[i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[i].Length + j] = IABarcoss[i][j];
                                }

                            }
                            break;
                        }
                }
            }
            for(int i=0; i<5-Hor;i++)
            {
                //IABarcoss[Hor+i][0] = r.Next(0, 9).ToString() + r.Next(0, 9).ToString();
                //Console.WriteLine("Vertical: " + IABarcoss[Hor+i][0]);
                switch (Hor+i)
                {
                    case 0:
                        {
                            xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[Hor + i].Length);
                            IABarcoss[Hor + i][0] = r.Next(0, 9).ToString() + r.Next(2, 7).ToString();
                            IABarcoss[Hor + i][1] = (int.Parse(IABarcoss[Hor + i][0]) + 1).ToString();
                            IABarcoss[Hor + i][2] = (int.Parse(IABarcoss[Hor + i][0]) + 2).ToString();
                            IABarcoss[Hor + i][3] = (int.Parse(IABarcoss[Hor + i][0]) - 1).ToString();
                            IABarcoss[Hor + i][4] = (int.Parse(IABarcoss[Hor + i][0]) - 2).ToString();
                            Console.WriteLine("Ver1: " + IABarcoss[Hor + i][0]);
                            for (int j = 0; j < IABarcoss[Hor+i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[Hor+i][j]) < 10)
                                {
                                    IABarcoss[Hor+i][j] = "0" + (int.Parse("0" + IABarcoss[Hor+i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[Hor+i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[Hor + i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[Hor + i].Length + j] = IABarcoss[Hor+i][j];
                                }

                            }
                            break;
                        }
                    case 1: //Barco de 4
                        {
                        xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[Hor + i].Length);
                            IABarcoss[Hor + i][0] = r.Next(0, 9).ToString() + r.Next(1, 7).ToString();
                            IABarcoss[Hor + i][1] = (int.Parse(IABarcoss[Hor + i][0]) + 1).ToString();
                            IABarcoss[Hor + i][2] = (int.Parse(IABarcoss[Hor + i][0]) + 2).ToString();
                            IABarcoss[Hor + i][3] = (int.Parse(IABarcoss[Hor + i][0]) - 1).ToString();
                            Console.WriteLine("Ver2: " + IABarcoss[Hor + i][0]);
                            for (int j = 0; j < IABarcoss[Hor+i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[Hor+i][j]) < 10)
                                {
                                    IABarcoss[Hor+i][j] = "0" + (int.Parse("0" + IABarcoss[Hor+i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[Hor+i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[Hor + i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[Hor + i].Length + j] = IABarcoss[Hor+i][j];
                                }

                            }
                            break;
                        }
                    case 2: //Barco de 3
                        {
                        xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[Hor + i].Length);
                            IABarcoss[Hor + i][0] = r.Next(0, 9).ToString() + r.Next(1, 8).ToString();
                            IABarcoss[Hor + i][1] = (int.Parse(IABarcoss[Hor + i][0]) + 1).ToString();
                            IABarcoss[Hor + i][2] = (int.Parse(IABarcoss[Hor + i][0]) - 1).ToString();
                            Console.WriteLine("Ver3: " + IABarcoss[Hor + i][0]);
                            for (int j = 0; j < IABarcoss[Hor+i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[Hor+i][j]) < 10)
                                {
                                    IABarcoss[Hor+i][j] = "0" + (int.Parse("0" + IABarcoss[Hor+i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[Hor+i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[Hor + i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[Hor + i].Length + j] = IABarcoss[Hor+i][j];
                                }

                            }
                            break;
                        }
                    case 3: //Barco de 3
                        {
                        xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[Hor + i].Length);
                            IABarcoss[Hor + i][0] = r.Next(0, 9).ToString() + r.Next(1, 8).ToString();
                            IABarcoss[Hor + i][1] = (int.Parse(IABarcoss[Hor + i][0]) + 1).ToString();
                            IABarcoss[Hor + i][2] = (int.Parse(IABarcoss[Hor + i][0]) - 1).ToString();
                            Console.WriteLine("Ver4: " + IABarcoss[Hor + i][0]);
                            for (int j = 0; j < IABarcoss[Hor+i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[Hor+i][j]) < 10)
                                {
                                    IABarcoss[Hor+i][j] = "0" + (int.Parse("0" + IABarcoss[Hor+i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[Hor+i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[Hor + i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[Hor + i].Length + j] = IABarcoss[Hor+i][j];
                                }

                            }
                            break;
                        }
                    case 4: //Barco de 2
                        {
                        xa:
                            Array.Resize(ref IABarcosClean, IABarcosClean.Length + IABarcoss[Hor + i].Length);
                            IABarcoss[Hor + i][0] = r.Next(0, 9).ToString() + r.Next(0, 8).ToString();
                            IABarcoss[Hor + i][1] = (int.Parse(IABarcoss[Hor + i][0]) + 1).ToString();
                            Console.WriteLine("Ver5: " + IABarcoss[Hor + i][0]);
                            for (int j = 0; j < IABarcoss[Hor+i].Length; j++)
                            {
                                if (int.Parse(IABarcoss[Hor+i][j]) < 10)
                                {
                                    IABarcoss[Hor+i][j] = "0" + (int.Parse("0" + IABarcoss[Hor+i][j])).ToString();
                                }
                                if (IABarcosClean.Contains(IABarcoss[Hor+i][j]))
                                {
                                    Array.Resize(ref IABarcosClean, IABarcosClean.Length - IABarcoss[Hor + i].Length);
                                    goto xa;
                                }
                                else
                                {
                                    IABarcosClean[IABarcosClean.Length - IABarcoss[Hor+i].Length + j] = IABarcoss[Hor+i][j];
                                }

                            }
                            break;
                        }
                }
            }
            Console.WriteLine("Barcos Clean:");
            for(int i=0; i<IABarcosClean.Length;i++)
            {
                Console.WriteLine(i+"-i-" +IABarcosClean[i]);
            }
        }

        //Funciones Tablero del jugador
        private void PbxTableroPlayer_Paint(object sender, PaintEventArgs e)
        {
            DrawBarcosPlayer(e);
            DrawBarcoPos(e);
            DrawDisparosIA(e);
            
            DrawTablero(e);

        }
        private void PbxTableroPlayer_MouseMove(object sender, MouseEventArgs e)
        {
            CheckShips(HoverShips);
            CanPlaceShip = false;
            Point xy = this.PointToClient(new Point(MousePosition.X, MousePosition.Y));
            int X = xy.X - PbxTableroPlayer.Location.X - (PbxTableroPlayer.Width / SizeTab);
            int Y = xy.Y - PbxTableroPlayer.Location.Y - (PbxTableroPlayer.Height / SizeTab);

            int XX = 0;
            int YY = 0;

            //Console.WriteLine("Posición X: " + X + " MP: " + MousePosition.X);
            //Console.WriteLine("Posición Y: " + Y + " MP: " + MousePosition.Y);
            if (X > 0 && Y > 0)
            {
                for (int i = 0; i < SizeTab; i++)
                {
                    if (X < (PbxTableroPlayer.Width / SizeTab))
                    {
                        XX = i;
                        break;
                    }
                    else
                    {
                        X -= (PbxTableroPlayer.Width / SizeTab);
                    }
                }
                for (int i = 0; i < SizeTab; i++)
                {
                    if (Y < (PbxTableroPlayer.Height / SizeTab))
                    {
                        YY = i;
                        break;
                    }
                    else
                    {
                        Y -= (PbxTableroPlayer.Height / SizeTab);
                    }
                }
                if (YY == 9)
                {
                    YY = 8;
                }
                string C = XX.ToString() + YY.ToString();
                PlayerBarcoPos = C;
                PbxTableroPlayer.Refresh();
                //Console.WriteLine(C);
            }
        }
        private void PbxTableroPlayer_Click(object sender, EventArgs e)
        {
            if (CanPlaceShip)
            {
                switch (CbxOrient.SelectedIndex)
                {
                    //Horizontal
                    case (0):
                        {
                            for (int i = 0; i < 5; i++)
                            {
                                if (PlayerBarcoss[i][0] == "99")
                                {
                                    switch (i)
                                    {
                                        case 0: //Barco de 5
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) + 20).ToString();
                                                PlayerBarcoss[i][3] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                                PlayerBarcoss[i][4] = (int.Parse(PlayerBarcoPos) - 20).ToString();
                                                break;
                                            }
                                        case 1: //Barco de 4
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) + 20).ToString();
                                                PlayerBarcoss[i][3] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                                break;
                                            }
                                        case 2: //Barco de 3
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                                break;
                                            }
                                        case 3: //Barco de 3
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                                break;
                                            }
                                        case 4: //Barco de 2
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                                BtnIniciar.Enabled = true;
                                                break;
                                            }
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    //Vertical
                    case (1):
                        {
                            for (int i = 0; i < 5; i++)
                            {
                                if (PlayerBarcoss[i][0] == "99")
                                {
                                    switch (i)
                                    {

                                        case 0: //Barco de 5
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) + 2).ToString();
                                                PlayerBarcoss[i][3] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                                PlayerBarcoss[i][4] = (int.Parse(PlayerBarcoPos) - 2).ToString();
                                                break;
                                            }
                                        case 1: //Barco de 4
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) + 2).ToString();
                                                PlayerBarcoss[i][3] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                                break;
                                            }
                                        case 2: //Barco de 3
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                                break;
                                            }
                                        case 3: //Barco de 3
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                                PlayerBarcoss[i][2] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                                break;
                                            }
                                        case 4: //Barco de 2
                                            {
                                                PlayerBarcoss[i][0] = PlayerBarcoPos;
                                                PlayerBarcoss[i][1] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                                BtnIniciar.Enabled = true;
                                                break;
                                            }
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                }
            }

            BlockShips();
            PbxTableroPlayer.Refresh();
            Console.WriteLine(PlayerBarcoPos);

        }
        void DrawBarcoPos(PaintEventArgs e) 
        {
            CanPlaceShip = false;
            int Hor = int.Parse(PlayerBarcoPos.Substring(0, 1)) + 1;
            int Ver = int.Parse(PlayerBarcoPos.Substring(1, 1)) + 1;

            e.Graphics.FillRectangle(Brushes.MediumVioletRed,
                (PbxTablero.Width / SizeTab) * (Hor),
                ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                (PbxTablero.Width / SizeTab),
                (PbxTablero.Height / SizeTab));

            switch (CbxOrient.SelectedIndex)
            {
                //Horizontal
                case (0):
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            if (PlayerBarcoss[i][0] == "99")
                            {
                                Array.Resize(ref HoverShips, 0);
                                Array.Resize(ref HoverShips, PlayerBarcoss[i].Length);
                                switch (i)
                                {
                                    case 0: //Barco de 5
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) + 20).ToString();
                                            HoverShips[3] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                            HoverShips[4] = (int.Parse(PlayerBarcoPos) - 20).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Hor < 8 && Hor > 2 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor - 2),
                    ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                    (PbxTablero.Width / SizeTab * 5),
                    (PbxTablero.Height / SizeTab));
                                            }

                                            break;
                                        }
                                    case 1: //Barco de 4
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) + 20).ToString();
                                            HoverShips[3] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Hor < 8 && Hor > 1 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor - 1),
                    ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                    (PbxTablero.Width / SizeTab * 4),
                    (PbxTablero.Height / SizeTab));
                                            }
                                            break;
                                        }
                                    case 2: //Barco de 3
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Hor < 9 && Hor > 1 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor - 1),
                    ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                    (PbxTablero.Width / SizeTab * 3),
                    (PbxTablero.Height / SizeTab));
                                            }
                                            break;
                                        }
                                    case 3: //Barco de 3
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) - 10).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Hor < 9 && Hor > 1 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor - 1),
                    ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                    (PbxTablero.Width / SizeTab * 3),
                    (PbxTablero.Height / SizeTab));
                                            }
                                            break;
                                        }
                                    case 4: //Barco de 2
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 10).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Hor < 9 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor),
                    ((PbxTablero.Height / SizeTab) * (Ver)) + (Ver),
                    (PbxTablero.Width / SizeTab * 2),
                    (PbxTablero.Height / SizeTab));
                                            }
                                            break;
                                        }
                                }
                                break;
                            }
                        }
                        break;
                    }
                //Vertical
                case (1):
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            if (PlayerBarcoss[i][0] == "99")
                            {
                                Array.Resize(ref HoverShips, 0);
                                Array.Resize(ref HoverShips, PlayerBarcoss[i].Length);
                                switch (i)
                                {
                                    case 0: //Barco de 5
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) + 2).ToString();
                                            HoverShips[3] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                            HoverShips[4] = (int.Parse(PlayerBarcoPos) - 2).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Ver < 8 && Ver > 2 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor),
                    ((PbxTablero.Height / SizeTab) * (Ver - 2)) + (Ver),
                    (PbxTablero.Width / SizeTab),
                    (PbxTablero.Height / SizeTab * 5));
                                            }

                                            break;
                                        }
                                    case 1: //Barco de 4
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) + 2).ToString();
                                            HoverShips[3] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Ver < 8 && Ver > 1 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor),
                    ((PbxTablero.Height / SizeTab) * (Ver - 1)) + (Ver),
                    (PbxTablero.Width / SizeTab),
                    (PbxTablero.Height / SizeTab * 4));
                                            }
                                            break;
                                        }
                                    case 2: //Barco de 3
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Ver < 9 && Ver > 1 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor),
                    ((PbxTablero.Height / SizeTab) * (Ver - 1)) + (Ver),
                    (PbxTablero.Width / SizeTab),
                    (PbxTablero.Height / SizeTab * 3));
                                            }
                                            break;
                                        }
                                    case 3: //Barco de 3
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) + 1).ToString();
                                            HoverShips[2] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Ver < 9 && Ver > 1 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor),
                    ((PbxTablero.Height / SizeTab) * (Ver - 1)) + (Ver),
                    (PbxTablero.Width / SizeTab),
                    (PbxTablero.Height / SizeTab * 3));
                                            }
                                            break;
                                        }
                                    case 4: //Barco de 2
                                        {
                                            HoverShips[0] = PlayerBarcoPos;
                                            HoverShips[1] = (int.Parse(PlayerBarcoPos) - 1).ToString();
                                            Console.WriteLine("HoverStart");
                                            for (int j = 0; j < HoverShips.Length; j++)
                                            {
                                                Console.WriteLine(HoverShips[j]);
                                            }
                                            Console.WriteLine("HoverEnd");
                                            if (Ver > 1 && CheckShips(HoverShips))
                                            {
                                                CanPlaceShip = true;
                                                e.Graphics.FillRectangle(Brushes.LightGreen,
                    (PbxTablero.Width / SizeTab) * (Hor),
                    ((PbxTablero.Height / SizeTab) * (Ver - 1)) + (Ver),
                    (PbxTablero.Width / SizeTab),
                    (PbxTablero.Height / SizeTab * 2));
                                            }
                                            break;
                                        }
                                }
                                break;
                            }
                        }
                        break;
                    }
            }
        }
        void DrawDisparosIA(PaintEventArgs e)
        {
            IAHit = 0;
            for (int i = 0; i < IADisparos; i++)
            {
                int Hor = int.Parse(IACoordDisparos[i].Substring(0, 1)) + 1;
                int Ver = int.Parse(IACoordDisparos[i].Substring(1, 1)) + 1;
                e.Graphics.FillEllipse(Brushes.White,
                    (PbxTableroPlayer.Width / SizeTab) * (Hor),
                    ((PbxTableroPlayer.Height / SizeTab) * (Ver)) + (Ver),
                    (PbxTableroPlayer.Width / SizeTab),
                    (PbxTableroPlayer.Height / SizeTab));
                //Console.WriteLine("White Snow");
                for (int j=0;j<PlayerBarcoss.Length;j++)
                {
                    if(PlayerBarcoss[j].Contains(IACoordDisparos[i]))
                    {
                        IAHit++;
                        e.Graphics.FillEllipse(Brushes.Crimson,
                   (PbxTableroPlayer.Width / SizeTab) * (Hor),
                   ((PbxTableroPlayer.Height / SizeTab) * (Ver)) + (Ver),
                   (PbxTableroPlayer.Width / SizeTab),
                   (PbxTableroPlayer.Height / SizeTab));
                        //Console.WriteLine("KING CRIMSON");
                        //break;
                    }
                }
            }

            if("Máquina: "+ IAHit.ToString()==LblImpIA.Text)
            {
                LblIADisplay.Text = "Máquina: Miss!";
            }
            else
            {
                LblIADisplay.Text = "Máquina: Hit!";
            }
            LblImpIA.Text = "Máquina: " + IAHit.ToString(); ;
            LblMissIA.Text = "Máquina: " + (IADisparos - IAHit).ToString();
            IACheck();
        }
        void DrawBarcosPlayer(PaintEventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < PlayerBarcoss[i].Length; j++)
                {
                    if (int.Parse(PlayerBarcoss[i][j]) <= 0)
                    {
                        PlayerBarcoss[i][j] = "00";
                    }
                    else if (int.Parse(PlayerBarcoss[i][j]) < 10)
                    {
                        PlayerBarcoss[i][j] = "0" + (int.Parse("0" + PlayerBarcoss[i][j])).ToString();
                    }
                    int Hor = int.Parse(PlayerBarcoss[i][j].Substring(0, 1)) + 1;
                    int Ver = int.Parse(PlayerBarcoss[i][j].Substring(1, 1)) + 1;
                    e.Graphics.FillRectangle(Brushes.DarkGray,
                        (PbxTableroPlayer.Width / SizeTab) * (Hor),
                        ((PbxTableroPlayer.Height / SizeTab) * (Ver)) + (Ver),
                        (PbxTableroPlayer.Width / SizeTab),
                        (PbxTableroPlayer.Height / SizeTab));
                }
            }
        }
        void BlockShips()
        {
            Array.Resize(ref ShipBlockade, 0);
            for (int i = 0; i < PlayerBarcoss.Length; i++)
            {
                if (PlayerBarcoss[i][0] != "99")
                {
                    Array.Resize(ref ShipBlockade, ShipBlockade.Length + PlayerBarcoss[i].Length);
                    for (int j = 0; j < PlayerBarcoss[i].Length; j++)
                    {
                        ShipBlockade[ShipBlockade.Length - PlayerBarcoss[i].Length + j] = PlayerBarcoss[i][j];
                    }
                }
            }

            Console.WriteLine("Ship blockade");
            for (int i = 0; i < ShipBlockade.Length; i++)
            {
                Console.WriteLine(ShipBlockade[i]);
            }
            Console.WriteLine("Ship blockade");

        }
        bool CheckShips(string[] CShips)
        {
            for (int i = 0; i < CShips.Length; i++)
            {
                if (int.Parse(CShips[i]) <= 0)
                {
                    CShips[i] = "00";
                }
                else if (int.Parse(CShips[i]) < 10)
                {
                    CShips[i] = "0" + (int.Parse(CShips[i])).ToString();
                }
                if (ShipBlockade.Contains(CShips[i]))
                {
                    CanPlaceShip = false;
                    return false;
                }
            }
            return true;
        }
        void CheckSunken()
        {
            int Sunken = 0;
            for(int i=0;i<IABarcoss.Length;i++)
            {
                for(int j=0;j<IABarcoss[i].Length;j++)
                {
                    if (PlayerCoordDisparos.Contains(IABarcoss[i][j]))
                    {
                        Sunken++;
                    }
                    if(Sunken==IABarcoss[i].Length)
                    {
                        switch(i)
                        {
                            case 0:
                                {
                                    PbxShip5.BackColor = Color.Red;
                                    break;
                                }
                            case 1:
                                {
                                    PbxShip4.BackColor = Color.Red;
                                    break;
                                }
                            case 2:
                                {
                                    PbxShip3.BackColor = Color.Red;
                                    break;
                                }
                            case 3:
                                {
                                    PbxShip2.BackColor = Color.Red;
                                    break;
                                }
                            case 4:
                                {
                                    PbxShip1.BackColor = Color.Red;
                                    break;
                                }
                        }
                    }
                    
                }
                Sunken = 0;
            }
            
        }

        
    }   
}
